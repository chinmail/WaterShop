﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Интерфейс для окон, отображающих список таблицы DataTable (класс вида TableListView)
    /// </summary>

    public interface ITableListView
    {
        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        Window Win { get; }

        /// <summary>
        /// Свойство для доступа к таблице listView1
        /// </summary>
        ListView List { get; }

        /// <summary>
        /// Свойство кнопок Enable: true - разблокировать кнопки , false - заблокировать кнопки 
        /// </summary>
        bool IsButtonEnabled { set; }

        /// <summary>
        /// Свойство: Сообщение в строке состояния
        /// </summary>
        string MessText
        { get; set; }       
    }
}
