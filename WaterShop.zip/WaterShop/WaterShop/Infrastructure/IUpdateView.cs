﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Интерфейс для диалоговых окон добавления/изменения строки таблицы (класс вида TableUpdateView)
    /// </summary>
    public interface ITableUpdateView
    {
        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        Window Win { get; }

        /// <summary>
        /// Код идентификатора
        /// </summary>
        int Id { get; set; }

        /// <summary>
        /// Иницилизация свойств экземпляра класса типа UpdateView
        /// </summary>
        /// <param name="presenter">Презентор списка покупателей</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки таблицы покупателей</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения</param>
        /// <param name="id">Код идентификатора покупателя</param>
        /// <param name="addParam">Необязательный дополнительный параметр для инициализации окна</param>
        void InitializeUpdateView(IPresenterUpdateView presenter, DataRowView rowView, DialogMode mode,
                                  int id = 0, object addParam = null);
    }
}
