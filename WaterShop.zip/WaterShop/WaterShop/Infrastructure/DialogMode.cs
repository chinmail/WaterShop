﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Перечисление режимов работы диалоговаго окна (Добавление, Изменение)
    /// </summary>
    public enum DialogMode
    {
        /// <summary>
        /// Режим добавления
        /// </summary>
        AddMode,
        /// <summary>
        /// Режим изменения
        /// </summary>
        ChangeMode
    }
}
