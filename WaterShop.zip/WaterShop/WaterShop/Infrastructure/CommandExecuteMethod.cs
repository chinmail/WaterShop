﻿using System;
namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Метод выполнения команды типа SqlCommand
    /// </summary>
    public enum CommandExecuteMethod
    {
        ExecuteScalar,      // Выполнить команду типа SqlCommand методом ExecuteScalar()
        ExecuteNonQuery,    // Выполнить команду типа SqlCommand методом ExecuteNonQuery()
        ExecuteReader       // Выполнить команду типа SqlCommand методом ExecuteReader()
    }
}
