﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Интерфейс презентера базовый (общие методы длявсех видов презенторов)
    /// </summary>
    public interface IPresenterBase
    {
        /// <summary>
        /// Выполнение SQL-команды, возвращающей текущую дату SQL-сервера,
        /// так как дата данного компьютера может не совпадать с датой SQL-сервера
        /// </summary>
        /// <returns></returns>
        DateTime GetDateNow();
    }
}
