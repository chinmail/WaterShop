﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Интерфейс презентера диалогового окна добавления/изменения строки таблицы (UpdateView)
    /// </summary>
    public interface IPresenterUpdateView: IPresenterBase
    {
        /// <summary>
        /// Добавление/изменение строки таблицы SQL-сервера при закрытии окна UpdateView
        /// Возвращает true - Отмена закрытия окна, false - закрытие окна
        /// </summary>
        /// <param name="rowView">Представление добавляемой или изменяемой строки таблицы</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения строки</param>
        /// <param name="id">Код идентификатора строки</param>
        /// <param name="dialogResult">Результат работы с диалоговым окном (true/false/null)</param>
        /// <returns></returns>
        bool UpdateViewClosing(DataRowView rowView, DialogMode mode, ref int id, bool? dialogResult);
    }
}
