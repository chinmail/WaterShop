﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Интерфейс презентера списка таблицы (ListView)
    /// </summary>
    public interface IPresenterListView: IPresenterBase
    {
        /// <summary>
        /// Перейти к первой строке таблицы
        /// </summary>
        void ToFirstRow();

        /// <summary>
        /// Перейти к последней строке таблицы
        /// </summary>
        void ToLastRow();

        /// <summary>
        /// Обновить строку row (DataRow) данными из соответствующей строки SQL-сервера
        /// </summary>
        /// <param name="row">Строка таблицы данных</param>
        void RefreshRow(DataRow row);

        /// <summary>
        /// Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)
        /// </summary>
        void FirstRefreshTable();

        /// <summary>
        /// Обновить список таблицы DataTable
        /// </summary>
        void RefreshTable();

        /// <summary>
        /// Добавить строку таблицы DataTable. Возвращает результат добавления.
        /// </summary>
        /// <param name="updateView">Диалоговое окно добавления/изменения строки табицы</param>
        /// <param name="addParam">Дополнительный параметр метода инициализации окна updateView</param>
        /// <returns>Возвращает результат добавления.</returns>
        bool? InsertRowTable(ITableUpdateView updateView, object addParam = null);

        /// <summary>
        /// Изменить выделенную строку таблицы DataTable. Возвращает результат изменения.
        /// </summary>
        /// <param name="updateView">Диалоговое окно добавления/изменения строки табицы</param>
        /// <returns>Возвращает результат изменения.</returns>
        bool? ChangeRowTable(ITableUpdateView updateView, object addParam = null);

        /// <summary>
        /// Удалить выделенную строку таблицы DataTable и соответствующую ей строку таблицы SQL-сервера
        /// Возвращает количество удаленных строк
        /// </summary>
        /// <returns>Возвращает количество удаленных строк</returns>
        int DeleteRowTable();
    }
}
