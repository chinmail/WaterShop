﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace WaterShop.Infrastructure
{
    /// <summary>
    /// Интерфейс модели данных: 
    /// Получение списка, добавление, изменение и удаление строки/строк из таблицы SQL-сервера 
    /// </summary>
    public interface ISqlTableModel
    {
        /// <summary>
        /// Выполнение SQL-команды, возвращающей текущую дату SQL-сервера,
        /// так как дата данного компьютера может не совпадать с датой SQL-сервера
        /// </summary>
        /// <returns></returns>
        DateTime GetDateNow();

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы SQL-сервера для выбора диапазона строк
        /// </summary>
        /// <returns>Возвращает созданную SQL-команду</returns>
        SqlCommand CreateSelectRowsSqlCommand();

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы SQL-сервера для выбора одной строки
        /// </summary>
        /// <param name="id">Код Id выбираемой строки</param>
        /// <returns>Возвращает созданную SQL-команду</returns>
        SqlCommand CreateSelectRowSqlCommand(int id);

        /// <summary>
        /// Добавить строку в таблицу SQL-сервера. Возвращает Id добавленной строки.
        /// возвращает -1 - ошибка при добавлении записи
        /// </summary>
        /// <param name="tableRow">Строка таблицы DataTable</param>
        int InsertTableRow(DataRow tableRow);

        /// <summary>
        /// Добавляет в таблицу SQL-сервера все строки таблицы DataTable, где RowState = DataRowState.Added
        /// </summary>
        /// <param name="table">Таблица DataTable</param>
        void InsertTableRows(DataTable table);

        /// <summary>
        /// Изменить строку в таблице SQL-сервера. Возвращает количество измененных строк.
        /// возвращает -1 - ошибка при добавлении записи
        /// </summary>
        /// <param name="tableRow">Строка таблицы DataTable</param>
        int ChangeTableRow(DataRow tableRow);

        /// <summary>
        /// Изменяет в таблице SQL-сервера все строки таблицы DataTable, где RowState = DataRowState.Modified
        /// </summary>
        /// <param name="table">Таблица DataTable</param>
        void ChangeTableRows(DataTable table);

        /// <summary>
        /// Удалить строку таблицы SQL-сервера. Возвращает количество удаленных строк.
        /// </summary>
        /// <param name="tableRow">Строка таблицы DataTable</param>
        int DeleteTableRow(DataRow TableRow);

        /// <summary>
        /// Удалить из таблицы SQL-сервера все строки таблицы DataTable, где RowState = DataRowState.Deleted
        /// </summary>
        /// <param name="table">Таблица DataTable</param>
        void DeleteTableRows(DataTable customers);
    }
}
