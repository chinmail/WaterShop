﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Окно списка таблицы покупателей 
    /// </summary>
    public partial class CustomersListView : Window, ITableListView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        CustomersPresenter presenter = null; // Презентор списка покупателей

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        /// <summary>
        /// Свойство для доступа к таблице listView1
        /// </summary>
        public ListView List { get { return listView1; } }

        /// <summary>
        /// Свойство кнопок Enable: true - разблокировать кнопки , false - заблокировать кнопки 
        /// </summary>
        public bool IsButtonEnabled
        {
            set
            {
                // Разблокировать кнопки
                if (value == true)
                {
                    insertBtn.IsEnabled = true;
                    changeBtn.IsEnabled = true;
                    deleteBtn.IsEnabled = true;
                    refreshBtn.IsEnabled = true;
                }
                // Заблокировать кнопки
                else
                {
                    insertBtn.IsEnabled = false;
                    changeBtn.IsEnabled = false;
                    deleteBtn.IsEnabled = false;
                    refreshBtn.IsEnabled = false;
                }
            }
        }

        /// <summary>
        /// Свойство: Сообщение в строке состояния
        /// </summary>
        public string MessText
        {
            get { return mess.Text; }
            set { mess.Text = value; }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        public CustomersListView()
        {
            InitializeComponent();

            // Презентор для таблицы покупателей
            presenter = this.Resources["customerPresenter"] as CustomersPresenter;
            presenter.TableListView = this;

            // Первый раз после загрузки окна типа CustomersListView обновить данные таблицы Customers
            presenter.FirstRefreshTable();
            // Передаем созданное представление элементу listView1 в качестве источника данных
            listView1.ItemsSource = presenter.CustomersView;

            // End: CustomersListView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            presenter.ToFirstRow();

            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка нажатий горячих клавиш
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyDown(object sender, KeyEventArgs args)
        {
            // Добавление покупателя
            if (args.Key == Key.Insert) InsertCustomer();

            // Изменение выделенного покупателя
            if (args.Key == Key.Enter) ChangeCustomer();

            // Удаление выделенного покупателя
            if (args.Key == Key.Delete) presenter.DeleteRowTable();

            // End: Window_KeyDown
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавить покупателя
        /// </summary>
        private void InsertCustomer()
        {
            // Диалоговое окно добавления/изменения покупателя
            CustomerUpdateView updateView = new CustomerUpdateView();

            // Добавить покупателя
            presenter.InsertRowTable(updateView);

            // End: InsertCustomer
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Изменить выделенного покупателя
        /// </summary>
        private void ChangeCustomer()
        {
            // Диалоговое окно добавления/изменения покупателя
            CustomerUpdateView updateView = new CustomerUpdateView();

            // Изменить выделенного покупателя
            presenter.ChangeRowTable(updateView);

            // End: ChangeCustomer
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Добавить покупателя"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void InsertBtn_Click(object sender, RoutedEventArgs args)
        {
            // Добавить покупателя
            InsertCustomer();

            // End: InsertBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Изменить покупателя"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ChangeBtn_Click(object sender, RoutedEventArgs args)
        {
            // Изменить выделенного покупателя
            ChangeCustomer();

            // End: ChangeBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Удалить покупателя"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void DeleteBtn_Click(object sender, RoutedEventArgs args)
        {
            // Удалить выделенного покупателя
            presenter.DeleteRowTable();

            // End: DeleteBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события двойного нажатия мыши по ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ListView1_MouseDoubleClick(object sender, MouseButtonEventArgs args)
        {
            // Изменить выделенного покупателя
            ChangeCustomer();

            // End: ListView1_MouseDoubleClick
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Обновить список"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void RefreshBtn_Click(object sender, RoutedEventArgs args)
        {
            // Обновить список покупателей
            presenter.RefreshTable();

            // End: RefreshBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Выйти из окна"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void CloseBtn_Click(object sender, RoutedEventArgs args)
        {
            // Закрыть окно
            Close();

            // End: CloseBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события, вызываемого при закрытии окна 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Сделать главное окно (MainWindow) активным
            this.Owner.Activate();

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
