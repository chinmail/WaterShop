﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Диалоговое окно добавления/изменения заголовка накладной
    /// </summary>
    public partial class NakHdrUpdateView : Window, ITableUpdateView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        IPresenterUpdateView presenter = null; // Поле: Презентор списка заголовков накладных

        int id; // Поле: Код идентификатора заголовка накладной

        int idCustomer; // Код покупателя

        // Презентор списка покупателей для заполнения набора данных ComboBox с именем CusFullName
        CustomersPresenter customersPresenter = null;

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство: Представление добавляемой или изменяемой строки таблицы заголовков накладных
        /// </summary>
        public DataRowView RowView { get; set; }

        /// <summary>
        /// Свойство: Режим добавления или изменения
        /// </summary>
        public DialogMode Mode { get; set; }

        /// <summary>
        /// Свойство: Код идентификатора заголовка накладной
        /// </summary>
        public int Id { get { return id; } set { id = value; } }

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Диалоговое окно добавления/изменения заголовка накладной
        /// </summary>
        public NakHdrUpdateView()
        {
            InitializeComponent();

            // End: NakHdrUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Диалоговое окно добавления/изменения заголовка накладной
        /// </summary>
        /// <param name="presenter">Презентор списка заголовков накладных</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки заголовка накладной</param>
        /// <param name="mode">Режим добавления/изменения заголовка накладной</param>
        /// <param name="id">Идентификатор товара (Id)</param>
        public NakHdrUpdateView(DataRowView rowView, DialogMode mode, int id = 0) : this()
        {
            // Иницилизация свойств экземпляра класса
            InitializeUpdateView(presenter, rowView, mode, id);

            // End: NakHdrUpdateView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                nakNumber.Focus();
            }
            // Иначе если режим изменения
            else
            {
                cancel.Focus();
            }
            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Иницилизация полей и свойств окна добавления/изменения заголовка накладной
        /// </summary>
        /// <param name="presenter">Презентор списка заголовков накладных</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки заголовка накладной</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения заголовка накладной</param>
        /// <param name="id">Идентификатор заголовка накладной (Id)</param>
        /// <param name="addParam">Необязательный дополнительный параметр для инициализации окна.
        /// В окне добавления/изменения заголовка накладной не используется</param>
        public void InitializeUpdateView(IPresenterUpdateView presenter, DataRowView rowView, DialogMode mode,
                                         int id = 0, object addParam = null)
        {
            this.presenter = presenter;     // Презентор списка заголовков накладных

            RowView = rowView;              // Представление добавляемой или изменяемой строки заголовков накладных
            Mode = mode;                    // Режим добавления/изменения покупателя
            Id = id;                        // Код идентификатора заголовка накладной

            // Инициализация презентора списка покупателей и привязка представление таблицы Customers
            // к набору данных ComboBox с именем CusFullName
            customersPresenter = new CustomersPresenter();

            // Первое обновление данных после инициализации презентора
            customersPresenter.FirstRefreshTable();
            cusFullName.ItemsSource = customersPresenter.CustomersView;

            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                Title = "Добавить накладную";
                RowView["NakDate"] = this.presenter.GetDateNow(); // Текущие дата и время
                RowView["NakNumber"] = (this.presenter as NakHdrPresenter).GetNakNumber(); // Номер текущей накладной
                RowView["idCustomer"] = 0;
                RowView["Summa"] = 0;

                idCustomer = 0; // Код покупателя
                cusFullName.Text = string.Empty;
            }
            // Иначе если режим изменения
            else if (Mode == DialogMode.ChangeMode)
            {
                Title = "Изменить накладную";

                idCustomer = (int)RowView["idCustomer"]; // Код покупателя
                try
                {
                    cusFullName.Text = (string)RowView["CusFullName"];
                }
                catch
                {
                    cusFullName.Text = string.Empty;
                }

                RowView.BeginEdit(); // Режим редактирования строки
            }

            // Приязка данных
            grid1.DataContext = RowView;

            // End: InitializeUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Согласен"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void Ok_Click(object sender, RoutedEventArgs args)
        {
            // Устанавливаем новое значение поля idCustomer
            if (cusFullName.Text != string.Empty)
            {
                // Если код покупателя изменился
                if (idCustomer != (int)cusFullName.SelectedValue)
                {
                    RowView["idCustomer"] = (int)cusFullName.SelectedValue;
                    RowView.Row.Table.Columns["CusFullName"].ReadOnly = false;
                    RowView["CusFullName"] = cusFullName.Text;
                    RowView.Row.Table.Columns["CusFullName"].ReadOnly = true;

                    idCustomer = (int)cusFullName.SelectedValue;
                }
            }

            // Проверка полей не допускающих null или пустое значение
            // ------------------------------------------------------

            // Номер накладной
            if (RowView["NakNumber"] == DBNull.Value || ((string)RowView["NakNumber"]).Trim() == "")
            {
                MessageBox.Show("Введите номер накладной", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                nakNumber.Focus();
                return;
            }

            // Код покупателя
            if (RowView["idCustomer"] == DBNull.Value || ((int)RowView["idCustomer"]) <= 0)
            {
                MessageBox.Show("Выберите покупателя", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                cusFullName.Focus();
                return;
            }

            // Завершить режим редактирования строки представления
            // ---------------------------------------------------
            try
            {
                RowView.EndEdit();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);

            }

            DialogResult = true;

            // End: Ok_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Отмена"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Cancel_Click(object sender, RoutedEventArgs args)
        {
            DialogResult = false;

            // End: Cancel_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработчик события перед закрытием окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Closing(object sender, CancelEventArgs args)
        {
            if (DialogResult == null) DialogResult = false;

            // Сохраняет изменения в MS SQL базе данных
            // ----------------------------------------
            args.Cancel = presenter.UpdateViewClosing(RowView, Mode, ref id, DialogResult);

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
