﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Окно списка таблицы заголовков накладных
    /// </summary>
    public partial class NakHdrListView : Window, ITableListView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        /// <summary>
        /// Презентор списка заголовков накладных
        /// </summary>
        NakHdrPresenter presenter = null; 

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        /// <summary>
        /// Свойство для доступа к таблице listView1
        /// </summary>
        public ListView List { get { return listView1; } }

        /// <summary>
        /// Свойство кнопок Enable: true - разблокировать кнопки , false - заблокировать кнопки 
        /// </summary>
        public bool IsButtonEnabled
        {
            set
            {
                // Разблокировать кнопки
                if (value == true)
                {
                    insertBtn.IsEnabled = true;
                    changeBtn.IsEnabled = true;
                    deleteBtn.IsEnabled = true;
                    refreshBtn.IsEnabled = true;
                }
                // Заблокировать кнопки
                else
                {
                    insertBtn.IsEnabled = false;
                    changeBtn.IsEnabled = false;
                    deleteBtn.IsEnabled = false;
                    refreshBtn.IsEnabled = false;
                }
            }
        }

        /// <summary>
        /// Свойство: Сообщение в строке состояния
        /// </summary>
        public string MessText
        {
            get { return mess.Text; }
            set { mess.Text = value; }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        public NakHdrListView()
        {
            InitializeComponent();

            // Презентор для таблицы покупателей
            presenter = this.Resources["nakHdrPresenter"] as NakHdrPresenter;
            presenter.TableListView = this;

            // Первый раз после загрузки окна типа NakHdrListView обновить данные таблицы NakHdr
            presenter.FirstRefreshTable();
            // Передаем созданное представление элементу listView1 в качестве источника данных
            listView1.ItemsSource = presenter.NakHdrView;

            // End: NakHdrListView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            presenter.ToFirstRow();

            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка нажатий горячих клавиш
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyDown(object sender, KeyEventArgs args)
        {
            // Добавление заголовка накладной
            if (args.Key == Key.Insert) InsertNakHdr();

            // Изменение выделенного заголовка накладной
            if (args.Key == Key.Enter) ChangeNakHdr();

            // Удаление выделенного заголовка накладной
            if (args.Key == Key.Delete) presenter.DeleteRowTable();

            // End: Window_KeyDown
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавить заголовок накладной
        /// </summary>
        private void InsertNakHdr()
        {
            // Добавление накладной
            presenter.InsertNakl();

            // Диалоговое окно добавления/изменения заголовка накладной
            //NakHdrUpdateView updateView = new NakHdrUpdateView();

            // Добавить заголовок накладной
            //presenter.InsertRowTable(updateView);

            // End: InsertNakHdr
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Изменить выделенного заголовок накладной
        /// </summary>
        private void ChangeNakHdr()
        {
            // Изменение накладной
            presenter.ChangeNakl();

            // Диалоговое окно добавления/изменения заголовка накладной
            //NakHdrUpdateView updateView = new NakHdrUpdateView();

            // Изменить выделенный заголовок накладной
            //presenter.ChangeRowTable(updateView);

            // End: ChangeNakHdr
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Добавить"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void InsertBtn_Click(object sender, RoutedEventArgs args)
        {
            // Добавить заголовок накладной
            InsertNakHdr();

            // End: InsertBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Изменить"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ChangeBtn_Click(object sender, RoutedEventArgs args)
        {
            // Изменить выделенный заголовок накладной
            ChangeNakHdr();

            // End: ChangeBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Удалить"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void DeleteBtn_Click(object sender, RoutedEventArgs args)
        {
            // Удалить заголовок накладной
            presenter.DeleteRowTable();

            // End: DeleteBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Свойства накладной"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void NaklPropBtn_Click(object sender, RoutedEventArgs args)
        {
            // Диалоговое окно добавления/изменения заголовка накладной
            NakHdrUpdateView updateView = new NakHdrUpdateView();

            // Изменить выделенный заголовок накладной
            presenter.ChangeRowTable(updateView);

            // End: ChangeBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события двойного нажатия мыши по ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ListView1_MouseDoubleClick(object sender, MouseButtonEventArgs args)
        {
            // Изменить выделенный заголовок накладной
            ChangeNakHdr();

            // End: ListView1_MouseDoubleClick
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Обновить список"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void RefreshBtn_Click(object sender, RoutedEventArgs args)
        {
            // Обновить список заголовков накладных
            presenter.RefreshTable();

            // End: RefreshBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Выйти из окна"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void CloseBtn_Click(object sender, RoutedEventArgs args)
        {
            // Закрыть окно
            Close();

            // End: CloseBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события, вызываемого при закрытии окна 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Сделать главное окно (MainWindow) активным
            this.Owner.Activate();

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
