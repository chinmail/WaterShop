﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Диалоговое окно добавления/изменения покупателя
    /// </summary>
    public partial class CustomerUpdateView : Window, ITableUpdateView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        IPresenterUpdateView presenter = null; // Поле: Презентор списка покупателей

        int id; // Поле: Код идентификатора покупателя

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство: Представление добавляемой или изменяемой строки таблицы покупателей
        /// </summary>
        public DataRowView RowView { get; set; } 

        /// <summary>
        /// Свойство: Режим добавления или изменения
        /// </summary>
        public DialogMode Mode { get; set; }     

        /// <summary>
        /// Свойство: Код идентификатора покупателя
        /// </summary>
        public int Id { get { return id; } set { id = value; } }                

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Диалоговое окно добавления/изменения покупателя
        /// </summary>
        public CustomerUpdateView()
        {
            InitializeComponent();

            // End: CustomerUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Диалоговое окно добавления/изменения покупателя
        /// </summary>
        /// <param name="presenter">Презентор списка покупателей</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки</param>
        /// <param name="mode">Режим добавления/изменения покупателя</param>
        /// <param name="id">Идентификатор покупателя (Id)</param>
        public CustomerUpdateView(DataRowView rowView, DialogMode mode, int id = 0) : this()
        {
            // Иницилизация свойств экземпляра класса
            InitializeUpdateView(presenter, rowView, mode, id);

            // End: CustomerUpdateView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                lName.Focus();
            }
            // Иначе если режим изменения
            else
            {
                cancel.Focus();
            }
            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Иницилизация полей и свойств окна добавления/изменения покупателя
        /// </summary>
        /// <param name="presenter">Презентор списка покупателей</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки таблицы покупателей</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения</param>
        /// <param name="id">Идентификатор покупателя (Id)</param>
        /// <param name="addParam">Необязательный дополнительный параметр для инициализации окна.
        /// В окне добавления/изменения покупателя не используется</param>
        public void InitializeUpdateView(IPresenterUpdateView presenter, DataRowView rowView, DialogMode mode,
                                         int id = 0, object addParam = null)
        {
            this.presenter = presenter;     // Презентор списка покупателей

            RowView = rowView;              // Представление добавляемой или изменяемой строки таблицы покупателей
            Mode = mode;                    // Режим добавления/изменения покупателя
            Id = id;                        // Код идентификатора покупателя

            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                Title = "Добавить покупателя";
                //RowView["DateInSystem"] = DateTime.Now; // Текущие дата и время
            }
            // Иначе если режим изменения
            else if (Mode == DialogMode.ChangeMode)
            {
                Title = "Изменить покупателя";
                RowView.BeginEdit(); // Режим редактирования строки
            }

            // Приязка данных
            grid1.DataContext = RowView;

            // End: InitializeUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Согласен"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void Ok_Click(object sender, RoutedEventArgs args)
        {
            // Проверка полей не допускающих null или пустое значение
            // ------------------------------------------------------

            // Фамилия
            if (RowView["LName"] == DBNull.Value || ((string)RowView["LName"]).Trim() == "")
            {
                MessageBox.Show("Введите фамилию", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                lName.Focus();
                return;
            }
            // Имя
            if (RowView["FName"] == DBNull.Value || ((string)RowView["FName"]).Trim() == "")
            {
                MessageBox.Show("Введите имя", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                fName.Focus();
                return;
            }
            // Город 
            if (RowView["City"] == DBNull.Value || ((string)RowView["City"]).Trim() == "")
            {
                MessageBox.Show("Введите город", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                city.Focus();
                return;
            }
            // Адрес 1
            if (RowView["Address1"] == DBNull.Value || ((string)RowView["Address1"]).Trim() == "")
            {
                MessageBox.Show("Введите адрес 1", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                address1.Focus();
                return;
            }
            // Телефон
            if (RowView["Phone"] == DBNull.Value || ((string)RowView["Phone"]).Trim() == "")
            {
                MessageBox.Show("Введите телефон", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                phone.Focus();
                return;
            }

            // Завершить режим редактирования строки представления
            // ---------------------------------------------------
            try
            {
                RowView.EndEdit();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);

            }

            DialogResult = true;

            // End: Ok_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Отмена"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Cancel_Click(object sender, RoutedEventArgs args)
        {
            DialogResult = false;

            // End: Cancel_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработчик события перед закрытием окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Closing(object sender, CancelEventArgs args)
        {
            if (DialogResult == null) DialogResult = false;

            // Сохраняет изменения в MS SQL базе данных
            // ----------------------------------------
            args.Cancel = presenter.UpdateViewClosing(RowView, Mode, ref id, DialogResult);

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
