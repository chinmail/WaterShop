﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Окно накладной
    /// </summary>
    public partial class NakLineListView : Window, ITableListView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        /// <summary>
        /// Код накладной
        /// </summary>
        int idNak;

        /// <summary>
        /// Представление строки заголоква накладной
        /// </summary>
        DataRowView nakHdrRowView = null;

        /// <summary>
        /// Презентор списка заголовков накладных
        /// </summary>
        NakHdrPresenter nakHdrPresenter = null;

        /// <summary>
        /// Презентор списка строк накладных
        /// </summary>
        NakLinePresenter presenter = null; 

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        /// <summary>
        /// Свойство для доступа к таблице listView1
        /// </summary>
        public ListView List { get { return listView1; } }

        /// <summary>
        /// Свойство кнопок Enable: true - разблокировать кнопки , false - заблокировать кнопки 
        /// </summary>
        public bool IsButtonEnabled
        {
            set
            {
                // Разблокировать кнопки
                if (value == true)
                {
                    insertBtn.IsEnabled = true;
                    changeBtn.IsEnabled = true;
                    deleteBtn.IsEnabled = true;
                    refreshBtn.IsEnabled = true;
                }
                // Заблокировать кнопки
                else
                {
                    insertBtn.IsEnabled = false;
                    changeBtn.IsEnabled = false;
                    deleteBtn.IsEnabled = false;
                    refreshBtn.IsEnabled = false;
                }
            }
        }

        /// <summary>
        /// Свойство: Сообщение в строке состояния
        /// </summary>
        public string MessText
        {
            get { return mess.Text; }
            set { mess.Text = value; }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Окно накладной
        /// </summary>
        public NakLineListView()
        {
            InitializeComponent();

            // Презентор для таблицы покупателей
            presenter = this.Resources["nakLinePresenter"] as NakLinePresenter;
            presenter.TableListView = this;          

            // End: NakLineListView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Окно накладной
        /// </summary>
        /// <param name="idNak">Код накладной</param>
        /// <param name="nakHdrRowView">Представление строки заголовка накладной</param>
        public NakLineListView(int idNak, NakHdrPresenter nakHdrPresenter, DataRowView nakHdrRowView=null) : this()
        {
            this.idNak = idNak; // Код накладной

            this.nakHdrPresenter = nakHdrPresenter; // Презентор заголовка накладной

            (presenter as NakLinePresenter).IdNak = idNak;

            // Первый раз после загрузки окна типа NakLineListView обновить данные таблицы NakLine
            presenter.FirstRefreshTable();
            // Передаем созданное представление элементу listView1 в качестве источника данных
            listView1.ItemsSource = presenter.NakLineView;

            // Представление строки заголовка накладной
            this.nakHdrRowView = nakHdrRowView; 
            // Приязка данных строки заголовка накладной
            gridNakHdr.DataContext = this.nakHdrRowView;
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            presenter.ToFirstRow();

            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка нажатий горячих клавиш
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyDown(object sender, KeyEventArgs args)
        {
            // Добавление строки накладной
            if (args.Key == Key.Insert) InsertNakLine();

            // Изменение выделенной строки накладной
            if (args.Key == Key.Enter) ChangeNakLine();

            // Удаление выделенной строки накладной
            if (args.Key == Key.Delete) DeleteNakLine();

            // End: Window_KeyDown
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавить строку накладной
        /// </summary>
        private void InsertNakLine()
        {
            // Диалоговое окно добавления/изменения строки накладной
            NakLineUpdateView updateView = new NakLineUpdateView();

            // Добавить покупателя
            presenter.InsertRowTable(updateView, idNak);

            // Обновить строку заголовка накладной
            if (nakHdrPresenter != null)
            {
                nakHdrPresenter.RefreshRow(nakHdrRowView.Row);
            }

            // End: InsertNakLine
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Изменить выделенную строку накладной
        /// </summary>
        private void ChangeNakLine()
        {
            // Диалоговое окно добавления/изменения строки накладной
            NakLineUpdateView updateView = new NakLineUpdateView();

            // Изменить выделенный заголовок накладной
            presenter.ChangeRowTable(updateView, idNak);

            // Обновить строку заголовка накладной
            if (nakHdrPresenter != null)
            {
                nakHdrPresenter.RefreshRow(nakHdrRowView.Row);
            }

            // End: ChangeNakLine
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Удалить выделенную строку накладной
        /// </summary>
        private void DeleteNakLine()
        {
            // Удалить выделенную строку накладной
            presenter.DeleteRowTable();

            // Обновить строку заголовка накладной
            if (nakHdrPresenter != null)
            {
                nakHdrPresenter.RefreshRow(nakHdrRowView.Row);
            }

            // End: DeleteNakLine
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Добавить"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void InsertBtn_Click(object sender, RoutedEventArgs args)
        {
            // Добавить строку накладной
            InsertNakLine();

            // End: InsertBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Изменить"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ChangeBtn_Click(object sender, RoutedEventArgs args)
        {
            // Изменить выделенную строку накладной
            ChangeNakLine();

            // End: ChangeBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Удалить"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void DeleteBtn_Click(object sender, RoutedEventArgs args)
        {
            // Удалить выделенную строку накладной
            DeleteNakLine();

            // End: DeleteBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события двойного нажатия мыши по ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ListView1_MouseDoubleClick(object sender, MouseButtonEventArgs args)
        {
            // Изменить выделенную строку накладной
            ChangeNakLine();

            // End: ListView1_MouseDoubleClick
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Обновить список"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void RefreshBtn_Click(object sender, RoutedEventArgs args)
        {
            // Обновить список строк накладных
            presenter.RefreshTable();

            // End: RefreshBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Выйти из окна"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void CloseBtn_Click(object sender, RoutedEventArgs args)
        {
            // Закрыть окно
            Close();

            // End: CloseBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события, вызываемого при закрытии окна 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Сделать главное окно (MainWindow) активным
            this.Owner.Activate();

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
