﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Диалоговое окно добавления/изменения товара
    /// </summary>
    public partial class ProductUpdateView : Window, ITableUpdateView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        IPresenterUpdateView presenter = null; // Поле: Презентор списка товаров

        int id; // Поле: Код идентификатора товара

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство: Представление добавляемой или изменяемой строки таблицы товаров
        /// </summary>
        public DataRowView RowView { get; set; }

        /// <summary>
        /// Свойство: Режим добавления или изменения
        /// </summary>
        public DialogMode Mode { get; set; }

        /// <summary>
        /// Свойство: Код идентификатора товара
        /// </summary>
        public int Id { get { return id; } set { id = value; } }

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Диалоговое окно добавления/изменения товара
        /// </summary>
        public ProductUpdateView()
        {
            InitializeComponent();

            // End: ProductUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Диалоговое окно добавления/изменения товара
        /// </summary>
        /// <param name="presenter">Презентор списка товаров</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки товара</param>
        /// <param name="mode">Режим добавления/изменения товара</param>
        /// <param name="id">Идентификатор товара (Id)</param>
        public ProductUpdateView(DataRowView rowView, DialogMode mode, int id = 0) : this()
        {
            // Иницилизация свойств экземпляра класса
            InitializeUpdateView(presenter, rowView, mode, id);

            // End: ProductUpdateView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                name.Focus();
            }
            // Иначе если режим изменения
            else
            {
                cancel.Focus();
            }
            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Иницилизация полей и свойств окна добавления/изменения товара
        /// </summary>
        /// <param name="presenter">Презентор списка товаров</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки товара</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения товара</param>
        /// <param name="id">Идентификатор товара (Id)</param>
        /// <param name="addParam">Необязательный дополнительный параметр для инициализации окна.
        /// В окне добавления/изменения товара не используется</param>
        public void InitializeUpdateView(IPresenterUpdateView presenter, DataRowView rowView, DialogMode mode,
                                         int id = 0, object addParam = null)
        {
            this.presenter = presenter;     // Презентор списка товаров

            RowView = rowView;              // Представление добавляемой или изменяемой строки товара
            Mode = mode;                    // Режим добавления/изменения товара
            Id = id;                        // Код идентификатора товара

            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                Title = "Добавить товар";
                //RowView["DateInSystem"] = DateTime.Now; // Текущие дата и время
            }
            // Иначе если режим изменения
            else if (Mode == DialogMode.ChangeMode)
            {
                Title = "Изменить товар";
                RowView.BeginEdit(); // Режим редактирования строки
            }

            // Приязка данных
            grid1.DataContext = RowView;

            // End: InitializeUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Согласен"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void Ok_Click(object sender, RoutedEventArgs args)
        {
            // Проверка полей не допускающих null или пустое значение
            // ------------------------------------------------------

            // Наименование товара
            if (RowView["Name"] == DBNull.Value || ((string)RowView["Name"]).Trim() == "")
            {
                MessageBox.Show("Введите наименование товара", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                name.Focus();
                return;
            }
            // Цена товара
            if (RowView["Price"] == DBNull.Value || (decimal)RowView["Price"] == 0)
            {
                MessageBox.Show("Введите цену товара", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                price.Focus();
                return;
            }
            // Единица измерения
            if (RowView["Unit"] == DBNull.Value || ((string)RowView["Unit"]).Trim() == "")
            {
                MessageBox.Show("Введите единицу измерения", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                unit.Focus();
                return;
            }

            // Завершить режим редактирования строки представления
            // ---------------------------------------------------
            try
            {
                RowView.EndEdit();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);

            }

            DialogResult = true;

            // End: Ok_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Отмена"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Cancel_Click(object sender, RoutedEventArgs args)
        {
            DialogResult = false;

            // End: Cancel_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработчик события перед закрытием окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Closing(object sender, CancelEventArgs args)
        {
            if (DialogResult == null) DialogResult = false;

            // Сохраняет изменения в MS SQL базе данных
            // ----------------------------------------
            args.Cancel = presenter.UpdateViewClosing(RowView, Mode, ref id, DialogResult);

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
