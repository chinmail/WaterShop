﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Окно списка таблицы товара
    /// </summary>
    public partial class ProductListView : Window, ITableListView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        ProductPresenter presenter = null; // Презентор списка товаров

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        /// <summary>
        /// Свойство для доступа к таблице listView1
        /// </summary>
        public ListView List { get { return listView1; } }

        /// <summary>
        /// Свойство кнопок Enable: true - разблокировать кнопки , false - заблокировать кнопки 
        /// </summary>
        public bool IsButtonEnabled
        {
            set
            {
                // Разблокировать кнопки
                if (value == true)
                {
                    insertBtn.IsEnabled = true;
                    changeBtn.IsEnabled = true;
                    deleteBtn.IsEnabled = true;
                    refreshBtn.IsEnabled = true;
                }
                // Заблокировать кнопки
                else
                {
                    insertBtn.IsEnabled = false;
                    changeBtn.IsEnabled = false;
                    deleteBtn.IsEnabled = false;
                    refreshBtn.IsEnabled = false;
                }
            }
        }

        /// <summary>
        /// Свойство: Сообщение в строке состояния
        /// </summary>
        public string MessText
        {
            get { return mess.Text; }
            set { mess.Text = value; }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Конструктор по умолчанию
        /// </summary>
        public ProductListView()
        {
            InitializeComponent();

            // Презентор для таблицы товаров
            presenter = this.Resources["productPresenter"] as ProductPresenter;
            presenter.TableListView = this;

            // Первый раз после загрузки окна типа ProductListView обновить данные таблицы Product
            presenter.FirstRefreshTable();
            // Передаем созданное представление элементу listView1 в качестве источника данных
            listView1.ItemsSource = presenter.ProductView;

            // End: ProductListView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            presenter.ToFirstRow();

            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка нажатий горячих клавиш
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyDown(object sender, KeyEventArgs args)
        {
            // Добавление товара
            if (args.Key == Key.Insert) InsertProduct();

            // Изменение выделенного товара
            if (args.Key == Key.Enter) ChangeProduct();

            // Удаление выделенного товара
            if (args.Key == Key.Delete) presenter.DeleteRowTable();

            // End: Window_KeyDown
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавить товар
        /// </summary>
        private void InsertProduct()
        {
            // Диалоговое окно добавления/изменения товара
            ProductUpdateView updateView = new ProductUpdateView();

            // Добавить товар
            presenter.InsertRowTable(updateView);

            // End: InsertProduct
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Изменить выделенный товар
        /// </summary>
        private void ChangeProduct()
        {
            // Диалоговое окно добавления/изменения товара
            ProductUpdateView updateView = new ProductUpdateView();

            // Изменить выделенного покупателя
            presenter.ChangeRowTable(updateView);

            // End: ChangeProduct
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Добавить товар"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void InsertBtn_Click(object sender, RoutedEventArgs args)
        {
            // Добавить товар
            InsertProduct();

            // End: InsertBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Изменить товар"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ChangeBtn_Click(object sender, RoutedEventArgs args)
        {
            // Изменить выделенный товар
            ChangeProduct();

            // End: ChangeBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Удалить товар"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void DeleteBtn_Click(object sender, RoutedEventArgs args)
        {
            // Удалить выделенный товар
            presenter.DeleteRowTable();

            // End: DeleteBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события двойного нажатия мыши по ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ListView1_MouseDoubleClick(object sender, MouseButtonEventArgs args)
        {
            // Изменить выделенный товар
            ChangeProduct();

            // End: ListView1_MouseDoubleClick
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Обновить список"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void RefreshBtn_Click(object sender, RoutedEventArgs args)
        {
            // Обновить список товаров
            presenter.RefreshTable();

            // End: RefreshBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Нажатие кнопки "Выйти из окна"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void CloseBtn_Click(object sender, RoutedEventArgs args)
        {
            // Закрыть окно
            Close();

            // End: CloseBtn_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события, вызываемого при закрытии окна 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Сделать главное окно (MainWindow) активным
            this.Owner.Activate();

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
