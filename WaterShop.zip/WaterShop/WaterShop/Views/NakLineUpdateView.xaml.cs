﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Presenters;
using WaterShop.Infrastructure;

namespace WaterShop.Views
{
    /// <summary>
    /// Диалоговое окно добавления/изменения строки накладной
    /// </summary>
    public partial class NakLineUpdateView : Window, ITableUpdateView
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        IPresenterUpdateView presenter = null; // Поле: Презентор списка заголовков накладных

        int id; // Поле: Код идентификатора заголовка накладной
        int idNak; // Код накладной

        int idProduct; // Код товара

        // Презентор списка товаров для заполнения набора данных ComboBox с именем pName
        ProductPresenter customersPresenter = null;

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство: Представление добавляемой или изменяемой строки таблицы заголовков накладных
        /// </summary>
        public DataRowView RowView { get; set; }

        /// <summary>
        /// Свойство: Режим добавления или изменения
        /// </summary>
        public DialogMode Mode { get; set; }

        /// <summary>
        /// Свойство: Код идентификатора заголовка накладной
        /// </summary>
        public int Id { get { return id; } set { id = value; } }

        /// <summary>
        /// Свойство для доступа к управлению свойствами и методами окна
        /// </summary>
        public Window Win { get { return this; } }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Диалоговое окно добавления/изменения строки накладной
        /// </summary>
        public NakLineUpdateView()
        {
            InitializeComponent();

            // End: NakHdrUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Диалоговое окно добавления/изменения строки накладной
        /// </summary>
        /// <param name="presenter">Презентор списка заголовков накладных</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки заголовка накладной</param>
        /// <param name="mode">Режим добавления/изменения заголовка накладной</param>
        /// <param name="id">Идентификатор товара (Id)</param>
        /// <param name="idNak">Код накладной (idNak)</param>
        public NakLineUpdateView(DataRowView rowView, DialogMode mode, int id = 0, int idNak = 0) : this()
        {
            // Иницилизация свойств экземпляра класса
            InitializeUpdateView(presenter, rowView, mode, id, idNak);

            // End: NakHdrUpdateView
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Обработка события после загрузки окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Loaded(object sender, RoutedEventArgs args)
        {
            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                pName.Focus();
            }
            // Иначе если режим изменения
            else
            {
                cancel.Focus();
            }
            // End: Window_Loaded
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Иницилизация полей и свойств окна добавления/изменения строки накладной
        /// </summary>
        /// <param name="presenter">Презентор строк накладной</param>
        /// <param name="rowView">Представление добавляемой или изменяемой строки накладной</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения строки накладной</param>
        /// <param name="id">Идентификатор строки накладной (Id)</param>
        /// <param name="addParam">Необязательный дополнительный параметр для инициализации окна.
        /// В окно добавления/изменения строки накладной передаются код накладной (idNak)</param>
        public void InitializeUpdateView(IPresenterUpdateView presenter, DataRowView rowView, DialogMode mode,
                                         int id = 0, object addParam = null)
        {
            this.presenter = presenter;     // Презентор списка строк накладных

            RowView = rowView;              // Представление добавляемой или изменяемой строки накладной
            Mode = mode;                    // Режим добавления/изменения
            Id = id;                        // Код идентификатора заголовка накладной

            // Код накладной
            idNak = 0;
            if (addParam != null)
            {
                if (addParam is int)
                {
                    idNak = (int)addParam;
                }
            }

            // Инициализация презентора списка товаров и привязка представление таблицы Product
            // к набору данных ComboBox с именем CusFullName
            customersPresenter = new ProductPresenter();
            // Первое обновление данных после инициализации презентора
            customersPresenter.FirstRefreshTable();
            pName.ItemsSource = customersPresenter.ProductView;

            // Если режим добавления
            if (Mode == DialogMode.AddMode)
            {
                Title = "Добавить строку накладной";

                RowView["idNak"] = idNak;
                RowView["idProduct"] = 0;

                idProduct = 0; // Код товара
                pName.Text = string.Empty;
            }
            // Иначе если режим изменения
            else if (Mode == DialogMode.ChangeMode)
            {
                Title = "Изменить строку накладную";
                RowView.BeginEdit(); // Режим редактирования строки

                idProduct = (int)RowView["idProduct"]; // Код товара
                try
                {
                    pName.Text = (string)RowView["PName"];
                }
                catch
                {
                    pName.Text = string.Empty;
                }
            }

            // Приязка данных
            grid1.DataContext = RowView;

            // End: InitializeUpdateView
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события при закрытии раскрывающего списка поля pName (ComboBox)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void PName_DropDownClosed(object sender, EventArgs args)
        {
            // Если код товара изменился
            if (idProduct != (int)pName.SelectedValue)
            {
                RowView["idProduct"] = (int)pName.SelectedValue;
                RowView["PName"] = pName.Text;

                DataRowView productRowView = pName.SelectedItem as DataRowView;

                if (productRowView != null)
                {
                    RowView["Unit"] = (string)productRowView["Unit"];
                    unit.Text = (string)productRowView["Unit"];
                    RowView["Price"] = (decimal)productRowView["Price"];
                    price.Text = ((decimal)productRowView["Price"]).ToString();

                    if ((RowView["Quantity"] != DBNull.Value) && (RowView["Price"] != DBNull.Value))
                    {
                        RowView["Summa"] = Convert.ToDecimal((int)RowView["Quantity"]) * (decimal)RowView["Price"];
                        summa.Text = ((decimal)RowView["Summa"]).ToString();
                    }
                }

                idProduct = (int)pName.SelectedValue;
            }

            // End: PName_DropDownClosed
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события при потери фокуса полем quantity
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Quantity_LostFocus(object sender, RoutedEventArgs args)
        {
            if ((RowView["Quantity"] != DBNull.Value) && (RowView["Price"] != DBNull.Value))
            {
                RowView["Summa"] = Convert.ToDecimal((int)RowView["Quantity"]) * (decimal)RowView["Price"];
                summa.Text = ((decimal)RowView["Summa"]).ToString();
            }

            // End: Quantity_LostFocus
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события при потери фокуса полем price
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Price_LostFocus(object sender, RoutedEventArgs args)
        {
            if ((RowView["Quantity"] != DBNull.Value) && (RowView["Price"] != DBNull.Value))
            {
                RowView["Summa"] = Convert.ToDecimal((int)RowView["Quantity"]) * (decimal)RowView["Price"];
                summa.Text = ((decimal)RowView["Summa"]).ToString();
            }

            // End: Price_LostFocus
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Согласен"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void Ok_Click(object sender, RoutedEventArgs args)
        {
            // Проверка полей не допускающих null или пустое значение
            // ------------------------------------------------------

            // Код товара
            if (RowView["idProduct"] == DBNull.Value || ((int)RowView["idProduct"]) <= 0)
            {
                MessageBox.Show("Выберите товар", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                pName.Focus();
                return;
            }

            // Количество
            if (RowView["Quantity"] == DBNull.Value || ((int)RowView["Quantity"]) <= 0)
            {
                MessageBox.Show("Введите количество", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                quantity.Focus();
                return;
            }

            // Цена
            if (RowView["Summa"] == DBNull.Value || ((decimal)RowView["Summa"]) <= 0)
            {
                MessageBox.Show("Введите цену", "Не заполнено обязательное поле", MessageBoxButton.OK, MessageBoxImage.Warning);
                price.Focus();
                return;
            }

            // Завершить режим редактирования строки представления
            // ---------------------------------------------------
            try
            {
                RowView.EndEdit();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);

            }

            // Если режим работы окна "Добавление строки"
            if (Mode == DialogMode.AddMode)
            {
                RowView["DateCre"] = DateTime.Now; // Присвоить текущие дату и время
                RowView["DateLast"] = RowView["DateCre"]; // Присвоить дату и время из поля DateCre
            }
            // Иначе если режим работы окна "Изменение строки"
            else
            {
                RowView["DateLast"] = DateTime.Now; // Присвоить текущие дату и время
            }

            DialogResult = true;

            // End: Ok_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка кнопки "Отмена"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Cancel_Click(object sender, RoutedEventArgs args)
        {
            DialogResult = false;

            // End: Cancel_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработчик события перед закрытием окна
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Closing(object sender, CancelEventArgs args)
        {
            if (DialogResult == null) DialogResult = false;

            // Сохраняет изменения в MS SQL базе данных
            // ----------------------------------------
            args.Cancel = presenter.UpdateViewClosing(RowView, Mode, ref id, DialogResult);

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
