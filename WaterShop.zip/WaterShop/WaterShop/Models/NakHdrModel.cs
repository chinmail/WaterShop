﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Infrastructure;

namespace WaterShop.Models
{
    /// <summary>
    /// Модель данных для таблицы NakHdr(заголовок накладной):
    /// Получение списка, добавление, изменение и удаление строки/строк из таблицы NakHdr(заголовок накладной) SQL-сервера 
    /// </summary>
    public class NakHdrModel : BaseTableModel
    {
        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Дата начала диапозона
        /// </summary>
        public DateTime Date1 { get; set; }

        /// <summary>
        /// Дата конца диапозона
        /// </summary>
        public DateTime Date2 { get; set; }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Модель данных: Добавление, изменение и удаление строки/строк таблицы NakHdr(заголовок накладной) SQL-сервера
        /// </summary>
        public NakHdrModel()
        {
            // End: NakHdrModel
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Иницилизации строк SQL-запросов и при необходимости присвоение значений другим полям класса.
        /// метод выполняется в конструкторе родительского класса BaseTableModel, поэтому можно инициализировать только поля,
        /// наследуемые от родительского класса
        /// </summary>
        protected override void InitializeField()
        {
            base.InitializeField();

            // Строка SQL-запроса с командой SELECT для выбора диапазона строк
            selectRowsCommandString = "SELECT NH.Id, NH.NakDate, NH.NakNumber, NH.idCustomer, " +
                "(Cus.LName + ' ' + Cus.FName + ' ' + Cus.MName) [CusFullName], NH.Summa, NH.DateCre, NH.DateLast " +
                "FROM NakHdr NH LEFT JOIN Customers Cus ON (NH.idCustomer = Cus.Id) " +
                "WHERE (NH.NakDate >= @Date1) AND (NH.NakDate <= @Date2)";

            //  Строка SQL-запроса с командой SELECT для выбора одной строки
            selectRowCommandString = "SELECT NH.Id, NH.NakDate, NH.NakNumber, NH.idCustomer, " +
                "(Cus.LName + ' ' + Cus.FName + ' ' + Cus.MName) [CusFullName], NH.Summa, NH.DateCre, NH.DateLast " +
                "FROM NakHdr NH LEFT JOIN Customers Cus ON (NH.idCustomer = Cus.Id) " +
                "WHERE NH.Id = @Id";

            // Строка SQL-запроса на добавление строки
            insertCommandString = "INSERT NakHdr(NakDate, NakNumber, idCustomer, Summa, DateCre, DateLast) " +
                                  "VALUES(GETDATE(), @NakNumber, @idCustomer, @Summa, GETDATE(), GETDATE()) " +
                                  "SELECT Id FROM NakHdr WHERE Id = @@IDENTITY";

            // Строка SQL-запроса на изменение строки
            updateCommandString = "UPDATE NakHdr SET NakNumber = @NakNumber, idCustomer = @idCustomer, " +
                                  "Summa = @Summa, DateLast = GETDATE() " +
                                  "WHERE Id = @Id";

            // Строка SQL-запроса на удаление строки
            //deleteCommandString = "DELETE NakHdr WHERE Id = @Id";

            deleteCommandString = "ws_DeleteNakl";

            // End: InitializeField
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Выполнение хранимой процедуры, для получения номера текущей накладной
        /// </summary>
        /// <returns></returns>
        public virtual string GetNakNumber()
        {
            string nakNumber = null; // Текстовый номер накладной

            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand("GetNakNumber", connection);
            cmd.CommandType = CommandType.StoredProcedure;

            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open(); // Открыть соединение
                }

                // Начать транзакцию
                cmd.Transaction = connection.BeginTransaction(IsolationLevel.Serializable);

                nakNumber = (string)cmd.ExecuteScalar(); // Выполнить команду с возвратом одного значения

                // Фиксирует изменения, произведенные в транзакции 
                cmd.Transaction.Commit();
            }
            catch (Exception exc)
            {
                // Отменяет изменения, произведенные в транзакции
                cmd.Transaction.Rollback();
                nakNumber = string.Empty;

                MessageBox.Show(exc.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                connection.Close(); // Закрыть соединение
            }

            return nakNumber;

            // End: GetNakNumber
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы NakHdr SQL-сервера для выбора диапазона строк
        /// </summary>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowsSqlCommand()
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(selectRowsCommandString, connection);
            cmd.Parameters.AddWithValue("Date1", Date1);
            cmd.Parameters.AddWithValue("Date2", Date2);

            return cmd;

            // End: CreateSelectRowsSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы NakHdr SQL-сервера для выбора одной строки
        /// </summary>
        /// <param name="id">Код Id выбираемой строки</param>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowSqlCommand(int id)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(selectRowCommandString, connection);
            cmd.Parameters.AddWithValue("Id", id);

            return cmd;

            // End: CreateSelectRowSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на добавление записи в таблицу NakHdr SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateInsertSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(insertCommandString, connection);
            cmd.Parameters.AddWithValue("NakNumber", customersRow["NakNumber"]);
            cmd.Parameters.AddWithValue("idCustomer", customersRow["idCustomer"]);
            cmd.Parameters.AddWithValue("Summa", customersRow["Summa"]);

            return cmd;

            // End: CreateInsertSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на изменение записи в таблице NakHdr SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateUpdateSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(updateCommandString, connection);
            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);
            cmd.Parameters.AddWithValue("NakNumber", customersRow["NakNumber"]);
            cmd.Parameters.AddWithValue("idCustomer", customersRow["idCustomer"]);
            cmd.Parameters.AddWithValue("Summa", customersRow["Summa"]);

            return cmd;

            // End: CreateUpdateSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на удаление записи в таблице NakHdr SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateDeleteSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(deleteCommandString, connection);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);

            return cmd;

            // End: CreateDeleteSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
