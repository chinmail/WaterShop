﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Infrastructure;

namespace WaterShop.Models
{
    /// <summary>
    /// Модель данных для таблицы Customers(покупатели):
    /// Получение списка, добавление, изменение и удаление строки/строк из таблицы Customers(покупатели) SQL-сервера 
    /// </summary>
    class CustomersModel : BaseTableModel
    {
        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Модель данных: Добавление, изменение и удаление строки/строк таблицы Customers(покупатели) SQL-сервера
        /// </summary>
        public CustomersModel()
        {
            // End: CustomersModel
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Иницилизации строк SQL-запросов и при необходимости присвоение значений другим полям класса.
        /// метод выполняется в конструкторе родительского класса BaseTableModel, поэтому можно инициализировать только поля,
        /// наследуемые от родительского класса
        /// </summary>
        protected override void InitializeField()
        {
            base.InitializeField();

            // Строка SQL-запроса с командой SELECT для выбора диапазона строк
            selectRowsCommandString = "SELECT *, (LName + ' ' + FName + ' ' + MName) [FullName] FROM Customers";

            //  Строка SQL-запроса с командой SELECT для выбора одной строки
            selectRowCommandString = "SELECT *, (LName + ' ' + FName + ' ' + MName) [FullName] " +
                                     "FROM Customers WHERE Id = @Id";

            // Строка SQL-запроса на добавление строки
            insertCommandString = "INSERT Customers(LName, FName, MName, City, Address1, Phone, DateCre, DateLast) " +
                                  "VALUES(@LName, @FName, @MName, @City, @Address1, @Phone, GETDATE(), GETDATE()) " +
                                  "SELECT Id FROM Customers WHERE Id = @@IDENTITY";

            // Строка SQL-запроса на изменение строки
            updateCommandString = "UPDATE Customers SET LName = @LName, FName = @FName, MName = @MName, " +
                                  "City = @City, Address1 = @Address1, Phone = @Phone, DateLast = GETDATE() " +
                                  "WHERE Id = @Id";

            // Строка SQL-запроса на удаление строки
            deleteCommandString = "DELETE Customers WHERE Id = @Id";

            // End: InitializeField
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы Customers SQL-сервера для выбора диапазона строк
        /// </summary>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowsSqlCommand()
        {
            SqlCommand cmd = new SqlCommand(selectRowsCommandString, connection);

            return cmd;

            // End: CreateSelectRowsSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы Customers SQL-сервера для выбора одной строки
        /// </summary>
        /// <param name="id">Код Id выбираемой строки</param>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowSqlCommand(int id)
        {
            SqlCommand cmd = new SqlCommand(selectRowCommandString, connection);
            cmd.Parameters.AddWithValue("Id", id);

            return cmd;

            // End: CreateSelectRowSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на добавление записи в таблицу Customers SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateInsertSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(insertCommandString, connection);
            cmd.Parameters.AddWithValue("LName", customersRow["LName"]);
            cmd.Parameters.AddWithValue("FName", customersRow["FName"]);
            cmd.Parameters.AddWithValue("MName", customersRow["MName"]);
            cmd.Parameters.AddWithValue("City", customersRow["City"]);
            cmd.Parameters.AddWithValue("Address1", customersRow["Address1"]);
            cmd.Parameters.AddWithValue("Phone", customersRow["Phone"]);

            return cmd;

            // End: CreateInsertSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на изменение записи в таблице Customers SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateUpdateSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(updateCommandString, connection);
            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);
            cmd.Parameters.AddWithValue("LName", customersRow["LName"]);
            cmd.Parameters.AddWithValue("FName", customersRow["FName"]);
            cmd.Parameters.AddWithValue("MName", customersRow["MName"]);
            cmd.Parameters.AddWithValue("City", customersRow["City"]);
            cmd.Parameters.AddWithValue("Address1", customersRow["Address1"]);
            cmd.Parameters.AddWithValue("Phone", customersRow["Phone"]);

            return cmd;

            // End: CreateUpdateSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на удаление записи в таблице Customers SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateDeleteSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(deleteCommandString, connection);
            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);

            return cmd;

            // End: CreateDeleteSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
