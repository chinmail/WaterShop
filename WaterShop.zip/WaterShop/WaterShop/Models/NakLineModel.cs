﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Infrastructure;

namespace WaterShop.Models
{
    /// <summary>
    /// Модель данных для таблицы NakLine(строки накладной):
    /// Получение списка, добавление, изменение и удаление строки/строк из таблицы NakLine(строки накладной) SQL-сервера 
    /// </summary>
    class NakLineModel : BaseTableModel
    {
        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Код накладной
        /// </summary>
        public int IdNak { get; set; }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Модель данных: Добавление, изменение и удаление строки/строк таблицы NakLine(строки накладной) SQL-сервера
        /// </summary>
        public NakLineModel()
        {

            // End: NakLineModel
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Иницилизации строк SQL-запросов и при необходимости присвоение значений другим полям класса.
        /// метод выполняется в конструкторе родительского класса BaseTableModel, поэтому можно инициализировать только поля,
        /// наследуемые от родительского класса
        /// </summary>
        protected override void InitializeField()
        {
            base.InitializeField();

            // Строка SQL-запроса с командой SELECT для выбора диапазона строк
            selectRowsCommandString = "SELECT NL.Id , NL.idNak, NL.idProduct, P.Name [PName], NL.Quantity, " +
                "P.Unit, NL.Price, NL.Summa, NL.DateCre, NL.DateLast " +
                "FROM NakLine NL LEFT JOIN Product P ON(NL.idProduct = P.Id) " +
                "WHERE NL.idNak = @idNak";

            //  Строка SQL-запроса с командой SELECT для выбора одной строки
            selectRowCommandString = "SELECT NL.Id, NL.idNak, NL.idProduct, P.Name [PName], NL.Quantity, " +
                "P.Unit, NL.Price, NL.Summa, NL.DateCre, NL.DateLast " +
                "FROM NakLine NL LEFT JOIN Product P ON(NL.idProduct = P.Id) " +
                "WHERE NL.Id = @Id";

            // Строка SQL-запроса на добавление строки
            //insertCommandString = "INSERT NakLine(idNak, idProduct, Quantity, Price, Summa, DateCre, DateLast) " +
            //                      "VALUES(@idNak, @idProduct, @Quantity, @Price, @Summa, GETDATE(), GETDATE()) " +
            //                      "SELECT Id FROM NakLine WHERE Id = @@IDENTITY";

            insertCommandString = "ws_InsertNakLine"; // Хранимая процедура

            // Строка SQL-запроса на изменение строки
            //updateCommandString = "UPDATE NakLine SET idProduct = @idProduct, Quantity = @Quantity, " +
            //                      "Price = @Price, Summa = @Summa, DateLast = GETDATE() " +
            //                      "WHERE Id = @Id";

            updateCommandString = "ws_UpdateNakLine"; // Хранимая процедура


            // Строка SQL-запроса на удаление строки
            //deleteCommandString = "DELETE NakLine WHERE Id = @Id";

            deleteCommandString = "ws_DeleteNakLine";

            // End: InitializeField
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы NakHdr SQL-сервера для выбора диапазона строк
        /// </summary>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowsSqlCommand()
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(selectRowsCommandString, connection);
            cmd.Parameters.AddWithValue("idNak", IdNak);

            return cmd;

            // End: CreateSelectRowsSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы NakHdr SQL-сервера для выбора одной строки
        /// </summary>
        /// <param name="id">Код Id выбираемой строки</param>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowSqlCommand(int id)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(selectRowCommandString, connection);
            cmd.Parameters.AddWithValue("Id", id);

            return cmd;

            // End: CreateSelectRowSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на добавление записи в таблицу NakHdr SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateInsertSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(insertCommandString, connection);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("idNak", customersRow["idNak"]);
            cmd.Parameters.AddWithValue("idProduct", customersRow["idProduct"]);
            cmd.Parameters.AddWithValue("Quantity", customersRow["Quantity"]);
            cmd.Parameters.AddWithValue("Price", customersRow["Price"]);
            cmd.Parameters.AddWithValue("Summa", customersRow["Summa"]);

            return cmd;

            // End: CreateInsertSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на изменение записи в таблице NakHdr SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateUpdateSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(updateCommandString, connection);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);
            cmd.Parameters.AddWithValue("idProduct", customersRow["idProduct"]);
            cmd.Parameters.AddWithValue("Quantity", customersRow["Quantity"]);
            cmd.Parameters.AddWithValue("Price", customersRow["Price"]);
            cmd.Parameters.AddWithValue("Summa", customersRow["Summa"]);

            return cmd;

            // End: CreateUpdateSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на удаление записи в таблице NakHdr SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateDeleteSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(deleteCommandString, connection);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);

            return cmd;

            // End: CreateDeleteSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        #endregion

    }
}
