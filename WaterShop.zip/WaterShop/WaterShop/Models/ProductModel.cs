﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Infrastructure;

namespace WaterShop.Models
{
    /// <summary>
    /// Модель данных для таблицы Product(товары):
    /// Получение списка, добавление, изменение и удаление строки/строк из таблицы Product(товары) SQL-сервера 
    /// </summary>
    public class ProductModel : BaseTableModel
    {
        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Модель данных: Добавление, изменение и удаление строки/строк таблицы Product(товары) SQL-сервера
        /// </summary>
        public ProductModel()
        {
            // End: ProductModel
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Иницилизации строк SQL-запросов и при необходимости присвоение значений другим полям класса.
        /// метод выполняется в конструкторе родительского класса BaseTableModel, поэтому можно инициализировать только поля,
        /// наследуемые от родительского класса
        /// </summary>
        protected override void InitializeField()
        {
            base.InitializeField();

            // Строка SQL-запроса с командой SELECT для выбора диапазона строк
            selectRowsCommandString = "SELECT * FROM Product";

            //  Строка SQL-запроса с командой SELECT для выбора одной строки
            selectRowCommandString = "SELECT * FROM Product WHERE Id = @Id";

            // Строка SQL-запроса на добавление строки
            insertCommandString = "INSERT Product(Name, Price, Unit, DateCre, DateLast) " +
                                  "VALUES(@Name , @Price, @Unit, GETDATE(), GETDATE()) " +
                                  "SELECT Id FROM Product WHERE Id = @@IDENTITY";

            // Строка SQL-запроса на изменение строки
            updateCommandString = "UPDATE Product SET Name = @Name, Price = @Price, Unit = @Unit, DateLast = GETDATE() " +
                                  "WHERE Id = @Id";

            // Строка SQL-запроса на удаление строки
            deleteCommandString = "DELETE Product WHERE Id = @Id";

            // End: InitializeField
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы Customers SQL-сервера для выбора диапазона строк
        /// </summary>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowsSqlCommand()
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(selectRowsCommandString, connection);

            return cmd;

            // End: CreateSelectRowsSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы Customers SQL-сервера для выбора одной строки
        /// </summary>
        /// <param name="id">Код Id выбираемой строки</param>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public override SqlCommand CreateSelectRowSqlCommand(int id)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(selectRowCommandString, connection);
            cmd.Parameters.AddWithValue("Id", id);

            return cmd;

            // End: CreateSelectRowSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на добавление записи в таблицу Customers SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateInsertSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(insertCommandString, connection);
            cmd.Parameters.AddWithValue("Name", customersRow["Name"]);
            cmd.Parameters.AddWithValue("Price", customersRow["Price"]);
            cmd.Parameters.AddWithValue("Unit", customersRow["Unit"]);
            cmd.Parameters.AddWithValue("DateCre", customersRow["DateCre"]);
            cmd.Parameters.AddWithValue("DateLast", customersRow["DateLast"]);

            return cmd;

            // End: CreateInsertSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на изменение записи в таблице Customers SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateUpdateSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(updateCommandString, connection);
            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);
            cmd.Parameters.AddWithValue("Name", customersRow["Name"]);
            cmd.Parameters.AddWithValue("Price", customersRow["Price"]);
            cmd.Parameters.AddWithValue("Unit", customersRow["Unit"]);
            cmd.Parameters.AddWithValue("DateCre", customersRow["DateCre"]);
            cmd.Parameters.AddWithValue("DateLast", customersRow["DateLast"]);

            return cmd;

            // End: CreateUpdateSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SQL-команду на удаление записи в таблице Customers SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected override SqlCommand CreateDeleteSqlCommand(DataRow customersRow, SqlConnection connection)
        {
            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand(deleteCommandString, connection);
            cmd.Parameters.AddWithValue("Id", customersRow["Id"]);

            return cmd;

            // End: CreateDeleteSqlCommand
            // ----------------------------------------------------------------------------------------
        }

        #endregion

    }
}
