﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Infrastructure;

namespace WaterShop.Models
{
    /// <summary>
    /// Базовая абстрактная модель данных для таблицы SQL-сервера:
    /// Получение списка, добавление, изменение и удаление строки/строк из таблицы SQL-сервера 
    /// </summary>
    public abstract class BaseTableModel : ISqlTableModel
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        /// <summary>
        /// Строка соединения c базой данных SQL-сервера
        /// @"Data Source=.\SERVER2012; Initial Catalog=WaterShop; Integrated Security=True; Pooling = true;"
        /// </summary>
        protected string connectionString = null;

        /// <summary>
        /// Соединенние с базой SQL-сервера
        /// </summary>
        protected SqlConnection connection = null;

        /// <summary>
        ///  Строка SQL-запроса с командой SELECT для выбора диапазона строк
        /// </summary>
        protected string selectRowsCommandString = null;

        /// <summary>
        ///  Строка SQL-запроса с командой SELECT для выбора одной строки
        /// </summary>
        protected string selectRowCommandString = null;

        /// <summary>
        ///  Строка SQL-запроса на добавление строки
        /// </summary>
        protected string insertCommandString = null;

        /// <summary>
        /// Строка SQL-запроса на изменение строки
        /// </summary>
        protected string updateCommandString = null;

        /// <summary>
        /// Строка SQL-запроса на удаление строки
        /// </summary>
        protected string deleteCommandString = null;

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Модель данных: Добавление, изменение и удаление строки/строк таблицы SQL-сервера
        /// </summary>
        public BaseTableModel()
        {
            /// Иницилизации строк SQL-запросов и при необходимости присвоение значений другим полям класса.
            InitializeField();

            // End: BaseTableModel
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Иницилизации строк SQL-запросов и при необходимости присвоение значений другим полям класса.
        /// </summary>
        protected virtual void InitializeField()
        {
            // Получение строки подключения к SQL-серверу из конфигурационного файла
            connectionString = (Application.Current as App).ConnectionString;

            // Соединенние с базой SQL-сервера
            connection = (Application.Current as App).Connection;

            // End: InitializeField
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Выполнение SQL-команды, возвращающей текущую дату SQL-сервера,
        /// так как дата данного компьютера может не совпадать с датой SQL-сервера
        /// </summary>
        /// <returns></returns>
        public virtual DateTime GetDateNow()
        {
            DateTime dateNow = DateTime.Now; // Текущая дата этого компьютера по умолчанию

            // Создание SQL-команды
            SqlCommand cmd = new SqlCommand("SELECT GETDATE()", connection);

            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open(); // Открыть соединение
                }

                dateNow = (DateTime)cmd.ExecuteScalar(); // Выполнить команду с возвратом одного значения
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                connection.Close(); // Закрыть соединение
            }

            return dateNow;

            // End: GetDateNow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Выполнение SQL-команды, не явлюющейся SELECT
        /// </summary>
        /// <param name="cmd">Команда</param>
        /// <param name="executeMethod">Метод выполнения команды</param>
        /// <returns></returns>
        protected virtual int ExecuteNonSelectCommand(SqlCommand cmd, CommandExecuteMethod executeMethod)
        {
            int result = 0; // Результат выполнения команды

            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open(); // Открыть соединение
                }

                // Начать транзакцию
                cmd.Transaction = connection.BeginTransaction(IsolationLevel.Serializable);

                // Выполнить команду типа SqlCommand методом ExecuteScalar()
                if (executeMethod == CommandExecuteMethod.ExecuteScalar)
                {
                    result = (int)cmd.ExecuteScalar(); // Выполнить команду с возвратом одного значения
                }
                // Выполнить команду типа SqlCommand методом ExecuteNonQuery()
                else if (executeMethod == CommandExecuteMethod.ExecuteNonQuery)
                {
                    result = cmd.ExecuteNonQuery(); // Выполнить команду не возвращающую значений
                }

                // Фиксирует изменения, произведенные в транзакции 
                cmd.Transaction.Commit();
            }
            catch (Exception exc)
            {
                // Отменяет изменения, произведенные в транзакции
                cmd.Transaction.Rollback();

                result = -1; // Код ошибки
                MessageBox.Show(exc.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                connection.Close(); // Закрыть соединение
            }

            return result;

            // End: ExecuteNonSelectCommand
            // ----------------------------------------------------------------------------------------
        }

        // ---------------------------------------------------------------------
        // Выбор
        // ---------------------------------------------------------------------

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы SQL-сервера для выбора диапазона строк
        /// </summary>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public abstract SqlCommand CreateSelectRowsSqlCommand();

        /// <summary>
        /// Создать SQL-команду SELECT из таблицы SQL-сервера для выбора одной строки
        /// </summary>
        /// <param name="id">Код Id выбираемой строки</param>
        /// <returns>Возвращает созданную SQL-команду</returns>
        public abstract SqlCommand CreateSelectRowSqlCommand(int id);

        // ---------------------------------------------------------------------
        // Добавление
        // ---------------------------------------------------------------------

        /// <summary>
        /// Создать SQL-команду на добавление записи в таблицу SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected abstract SqlCommand CreateInsertSqlCommand(DataRow tableRow, SqlConnection connection);

        /// <summary>
        /// Добавить строку в таблицу SQL-сервера. Возвращает Id добавленной строки.
        /// возвращает -1 - ошибка при добавлении записи
        /// </summary>
        /// <param name="tableRow">Строка таблицы</param>
        public virtual int InsertTableRow(DataRow tableRow)
        {
            int id = 0; // Id новой строки таблицы SQL-сервера

            // Создать SQL-команду на добавление записи в таблицу SQL-сервера
            SqlCommand cmd = CreateInsertSqlCommand(tableRow, connection);

            // Выполнить команду методом ExecuteScalar()
            id = ExecuteNonSelectCommand(cmd, CommandExecuteMethod.ExecuteScalar);

            // Если в ходе выполнения не произошла ошибка, то присвоить Id строки tableRow
            // значение соответствующей строки из SQL-сервера
            if (id != -1)
            {
                tableRow.Table.Columns["Id"].ReadOnly = false;
                tableRow["Id"] = id;
                tableRow.Table.Columns["Id"].ReadOnly = true;
            }
                
            return id;

            // End: InsertTableRow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавляет в таблицу SQL-сервера все строки соответствующей ей таблицы DataTable, где RowState = DataRowState.Added
        /// </summary>
        /// <param name="table">Таблица DataTable</param>
        public virtual void InsertTableRows(DataTable table)
        {
            foreach (DataRow row in table.Rows)
            {
                if (row.RowState == DataRowState.Added)
                {
                    InsertTableRow(row);
                    row.AcceptChanges();
                }
            }

            // End: InsertTableRows
            // ----------------------------------------------------------------------------------------
        }

        // ---------------------------------------------------------------------
        // Изменение
        // ---------------------------------------------------------------------

        /// <summary>
        /// Создать SQL-команду на изменение записи в таблице SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected abstract SqlCommand CreateUpdateSqlCommand(DataRow tableRow, SqlConnection connection);

        /// <summary>
        /// Изменить строку в таблице SQL-сервера. Возвращает количество изменененных строк.
        /// возвращает -1 - ошибка при изменении записи
        /// </summary>
        /// <param name="tableRow">Строка таблицы</param>
        public virtual int ChangeTableRow(DataRow tableRow)
        {
            int countChange = 0; // Количество измененных строк

            // Создать SQL-команду на изменение записи в таблице SQL-сервера
            SqlCommand cmd = CreateUpdateSqlCommand(tableRow, connection);

            // Если вызывается хранимая процедура
            if (cmd.CommandType == CommandType.StoredProcedure)
            {
                // Выполнить команду методом ExecuteScalar()
                countChange = ExecuteNonSelectCommand(cmd, CommandExecuteMethod.ExecuteScalar);
            }
            // Иначе
            else
            {
                // Выполнить команду методом ExecuteNonQuery()
                countChange = ExecuteNonSelectCommand(cmd, CommandExecuteMethod.ExecuteNonQuery);
            }

            return countChange;

            // End: ChangeTableRow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Изменяет в таблице SQL-сервера все строки соответствующей ей таблицы DataTable, где RowState = DataRowState.Modified
        /// </summary>
        /// <param name="table">Таблица покупателей</param>
        public virtual void ChangeTableRows(DataTable table)
        {
            foreach (DataRow row in table.Rows)
            {
                if (row.RowState == DataRowState.Modified)
                {
                    ChangeTableRow(row);
                    row.AcceptChanges();
                }
            }

            // End: ChangeTableRows
            // ----------------------------------------------------------------------------------------
        }

        // ---------------------------------------------------------------------
        // Удаление
        // ---------------------------------------------------------------------

        /// <summary>
        /// Создать SQL-команду на удаление записи в таблице SQL-сервера
        /// </summary>
        /// <returns></returns>
        protected abstract SqlCommand CreateDeleteSqlCommand(DataRow tableRow, SqlConnection connection);

        /// <summary>
        /// Удалить строку таблицы Customers SQL-сервера. Возвращает количество удаленных строк.
        /// </summary>
        /// <param name="tableRow">Строка таблицы</param>
        public virtual int DeleteTableRow(DataRow tableRow)
        {
            int countDelete = 0; // Количество удаленных строк

            // Создать SQL-команду на удаление записи в таблице SQL-сервера
            SqlCommand cmd = CreateDeleteSqlCommand(tableRow, connection);

            // Если вызывается хранимая процедура
            if (cmd.CommandType == CommandType.StoredProcedure)
            {
                // Выполнить команду методом ExecuteScalar()
                countDelete = ExecuteNonSelectCommand(cmd, CommandExecuteMethod.ExecuteScalar);
            }
            // Иначе
            else
            {
                // Выполнить команду методом ExecuteNonQuery()
                countDelete = ExecuteNonSelectCommand(cmd, CommandExecuteMethod.ExecuteNonQuery);
            }

            return countDelete;

            // End: DeleteTableRow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Удалить из таблице SQL-сервера все строки соответствующей ей таблицы DataTable, где RowState = DataRowState.Deleted
        /// </summary>
        /// <param name="table">Таблица покупателей</param>
        public virtual void DeleteTableRows(DataTable table)
        {
            foreach (DataRow row in table.Rows)
            {
                if (row.RowState == DataRowState.Deleted)
                {
                    DeleteTableRow(row);
                    row.AcceptChanges();
                }
            }

            // End: DeleteTableRows
            // ----------------------------------------------------------------------------------------
        }

        #endregion
    }
}
