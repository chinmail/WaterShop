﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Windows.Threading;
using WaterShop.Models;
using WaterShop.Infrastructure;

namespace WaterShop.Presenters
{
    /// <summary>
    /// Презентор списка покупателей
    /// </summary>
    public class CustomersPresenter : BaseTablePresenter
    {
        /// <summary>
        /// Свойство: Представление таблицы customers
        /// </summary>
        public DataView CustomersView
        {
            get
            {
                return tableView;
            }
            set
            {
                tableView = value;
            }
        }

        /// <summary>
        /// Презентор для списка покупателей
        /// </summary>
        public CustomersPresenter()
        {
            // Инициализация модели данных: Добавление, изменение и удаление строки/строк таблицы Customers(покупатели) SQL-сервера
            model = new CustomersModel();

            // Имя таблицы DataTable
            tableName = "Customers";

            // Строка сортировки для строк представления tableView
            sortString = "LName, FName";

            // Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)
            //FirstRefreshTable();

            // End: CustomersPresenter
            // ----------------------------------------------------------------------------------------
        }
    }
}
