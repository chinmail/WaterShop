﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using WaterShop.Models;
using WaterShop.Infrastructure;

namespace WaterShop.Presenters
{
    /// <summary>
    /// Базовый презентор для таблицы DataTable и соответствующей ее таблицы SQL-сервера
    /// Сооединяет два окна типа TableListView и TableUpdateView с источником данных типа TableModel
    /// </summary>
    public abstract class BaseTablePresenter : IPresenterListView, IPresenterUpdateView
    {
        /// <summary>
        /// Делегат для передачи трех аргументов: новой таблицы (newTable),
        /// Id (selectedId) и индекса (selectedIndex) выделенной строки старой таблицы
        /// </summary>
        protected delegate void ThreeArgDelegate(DataTable newTable, int selectedId, int selectedIndex);

        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        /// <summary>
        /// // Сообщение об ошибке
        /// </summary>
        protected string errorMessage;

        /// <summary>
        /// Ссылка на соответствующее презентору окно списка вида TableListView
        /// </summary>
        protected ITableListView tableListView = null;

        /// <summary>
        /// Модель данных: Получение списка, добавление, изменение и удаление строки/строк из таблицы SQL-сервера
        /// </summary>
        protected ISqlTableModel model = null;

        /// <summary>
        /// SqlDataAdapter для заполнения таблицы типа DataTable диапазоном строк из таблицы SQL-сервера
        /// </summary>
        protected SqlDataAdapter adapterRows = null;

        /// <summary>
        /// SqlDataAdapter для заполнения таблицы типа DataTable одной строкой из таблицы SQL-сервера
        /// </summary>
        protected SqlDataAdapter adapterRow = null;

        /// <summary>
        /// Текущая таблица данных типа DataTable
        /// </summary>
        protected DataTable table = null;

        /// <summary>
        /// Текущее представление типа DataView таблицы данных типа DataTable
        /// </summary>
        protected DataView tableView = null;

        /// <summary>
        /// Имя таблицы DataTable
        /// </summary>
        protected string tableName;

        /// <summary>
        /// Строка сортировки для строк представления tableView
        /// </summary>
        protected string sortString;

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство: Ссылка на соответствующее презентору окно вида TableListView
        /// </summary>
        public ITableListView TableListView
        {
            get { return tableListView; }
            set { tableListView = value; }
        }

        /// <summary>
        /// Модель данных: Получение списка, добавление, изменение и удаление строки/строк из таблицы SQL-сервера
        /// </summary>
        public ISqlTableModel Model
        {
            get { return model; }
            set { model = value; }
        }

        /// <summary>
        /// Свойство: Текущая таблица данных типа DataTable 
        /// </summary>
        public DataTable Table
        {
            get
            {
                return table;
            }
            set
            {
                table = value;
            }
        }

        /// <summary>
        /// Свойство: Текущее представление (типа TableListView) таблицы DataTable для передачи набора данных в ItemSource 
        /// объекта List (типа ListView)
        /// </summary>
        public DataView TableView
        {
            get
            {
                return tableView;
            }
            set
            {
                tableView = value;
            }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Базовый презентор для таблицы DataTable и соответствующей ее таблицы SQL-сервера
        /// Сооединяет два окна типа TableListView и TableUpdateView с источником данных типа TableModel
        /// </summary>
        public BaseTablePresenter()
        {
            // раскоментировать тело конструктора в наследуемом конкретном классе
            // -----------------------------------------------------------------------------------------------

            // Инициализация модели данных: Добавление, изменение и удаление строки/строк таблицы SQL-сервера
            // в наследуемом конкретном классе инициализируется модель, связанная с этим классом 
            // -----------------------------------------------------------------------------------------------
            // model = new BaseTableModel(); 

            // Имя таблицы DataTable
            // tableName = "Table"

            // Строка сортировки для строк представления tableView
            // sortString = "LName, FName";

            // Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)            
            // FirstRefreshTable();

            // End: BaseTablePresenter
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Выполнение SQL-команды, возвращающей текущую дату SQL-сервера,
        /// так как дата данного компьютера может не совпадать с датой SQL-сервера
        /// </summary>
        /// <returns></returns>
        public virtual DateTime GetDateNow()
        {
            return model.GetDateNow();

            // End: GetDateNow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Установить фокус на выделенную строку 
        /// </summary>
        public virtual void SetFocusToSelectedItem()
        {
            //MessageBox.Show(tableListView.List.SelectedIndex.ToString());

            // Если существует выделенная строка, то устоновить на ней фокус
            if (tableListView.List.SelectedIndex > -1)
            {
                // Обеспечивает правильное обновление всех визуальных дочерних элементов данного элемента для макета
                // Перересует строку таблицы до того как будет предпринята попытка установить на ней фокус
                tableListView.List.UpdateLayout();

                try
                {
                    // Вернуть контейнер для выделенной строки в виде UIElement и установить на ней фокус
                    UIElement uIElement = tableListView.List.ItemContainerGenerator.
                                          ContainerFromIndex(tableListView.List.SelectedIndex) as UIElement;                  
                    uIElement.Focus();


                    //ListViewItem lvi = tableListView.List.ItemContainerGenerator.ContainerFromIndex(tableListView.List.SelectedIndex)
                    //                   as ListViewItem;
                    //lvi.Focus();

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message, "Ошибка при установке фокуса на строку таблицы",
                                    MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            // End: SetFocusToSelectedItem
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Перейти к первой строке таблицы
        /// </summary>
        public virtual void ToFirstRow()
        {
            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;

            // Если в ItemsSource listView1 не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return;

            // Если число строк в представлении равно нулю, то завершить метод
            if (currentTableView.Count == 0) return;

            // Первая строка представления
            DataRowView firstRow = currentTableView[0];

            // Если firstRow не null, то сделать её текущей и выделенной
            if (firstRow != null)
            {
                tableListView.List.SelectedItem = firstRow;
                tableListView.List.ScrollIntoView(firstRow);
            }

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();

            // End: ToFirstRow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Перейти к последней строке таблицы
        /// </summary>
        public virtual void ToLastRow()
        {
            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;

            // Если в ItemsSource listView1 не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return;

            // Если число строк в представлении равно нулю, то завершить метод
            if (currentTableView.Count == 0) return;

            // Последняя строка представления
            DataRowView lastRow = currentTableView[currentTableView.Count - 1];

            // Если lastRow не null, то сделать её текущей и выделенной
            if (lastRow != null)
            {
                tableListView.List.SelectedItem = lastRow;
                tableListView.List.ScrollIntoView(lastRow);
            }

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();

            // End: ToLastRow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Поиск строки представления (DataRowView) по коду идентификатора (Id).
        /// Если поиск успешный возвращает найденную строку представления, иначе возвращает null
        /// </summary>
        /// <param name="id">Код идентификатора</param>
        /// <returns></returns>
        public virtual DataRowView FindRowViewById(int id)
        {
            // Локальные переменные метода
            // ---------------------------

            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;
            // Искомая строка представления
            DataRowView rowViewfind = null; 

            // Проверки на допустимость выполнения метода
            // ------------------------------------------

            // Если в ItemsSource List не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return null;

            // Поиск искомой строки представления путем перебора всех строк представления таблицы DataTable
            // ---------------------------------------------------------------------------------------------
            for (int i = 0; i < currentTableView.Count; i++)
            {
                if ((int)currentTableView[i]["Id"] == id)
                {
                    rowViewfind = currentTableView[i];
                    break;
                }
            }

            // Если строка найдена, то возвращает строку с кодом идентификатора равным id, иначе null  
            return rowViewfind;

            // End: FindRowViewById
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Сделать выделенной строкой строку с Id = selectedId.
        /// Если такая строка не найдена, то строку с индексом равным selectedIndex.
        /// </summary>
        /// <param name="selectedId">Id - выделенной строки</param>
        /// <param name="selectedIndex">Индекс выделенной строки</param>
        public virtual void SelectedRowViewById(int selectedId, int selectedIndex)
        {
            // Локальные переменные метода
            // ---------------------------
            DataView currentTableView = tableListView.List.ItemsSource as DataView; // Представление таблицы DataTable
            DataRowView rowViewSelected = null; // выделенная строка listView1

            // Проверки на допустимость выполнения метода
            // ------------------------------------------

            // Если в ItemsSource listView1 не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return;

            // Если selectedId = 0, то завершить метод
            if (selectedId == 0) return;

            // Если selectedIndex < 0, то завершить метод
            if (selectedIndex < 0) return;

            // Найти строку с Id = selectedId и сделать ее выделенной или 
            // если такой строки нет, то строку с индексом selectedIndex
            // -----------------------------------------------------------------
            rowViewSelected = FindRowViewById(selectedId); // Поиск строки представления по коду идентификатора (Id)

            // Если строка представления найдена, сделать ее выделенной,
            // Иначе сделать выделенной строку с индексом равным selectedIndex
            if (rowViewSelected != null)
            {
                tableListView.List.SelectedItem = rowViewSelected;
                tableListView.List.ScrollIntoView(rowViewSelected);
            }
            else
            {
                // Если индекс выделенного элемента больше максимального индекса представления, то сделать выделенный элемент последним
                if (selectedIndex > currentTableView.Count - 1)
                {
                    selectedIndex = currentTableView.Count - 1;
                }

                // Если в представлении осталась хоть одна строка, то сделать строку с индексом selectedIndex выделенной
                if (selectedIndex >= 0)
                {
                    rowViewSelected = currentTableView[selectedIndex];
                    tableListView.List.SelectedItem = rowViewSelected;
                    tableListView.List.ScrollIntoView(rowViewSelected);
                }
            }

            // ----------------------------------------------------------------------------------------
            // End: SelectedRowViewById
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Создать SqlDataAdapter по SQL-команде cmd
        /// </summary>
        /// <param name="cmd">SQL-команда</param>
        /// <returns></returns>
        protected virtual SqlDataAdapter CreateSqlAdapter(SqlCommand cmd)
        {
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;

            return adapter;

            // End: CreateSqlAdapter
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// C помощью SQL-адаптара (adapter)
        /// заполняет настройки схемы таблицы currentTable из соответствующей её таблицы SQL-сервера
        /// </summary>
        /// <param name="adapter">SQL-адаптар</param>
        /// <param name="currentTable">текущая таблица</param>
        protected virtual void FillSchemaTable(SqlDataAdapter adapter, DataTable currentTable)
        {
            // Заполнить настройки схемы таблицы currentTable
            adapter.FillSchema(currentTable, SchemaType.Mapped);

            // Дополнительные настройки схемы таблицы currentTable, 
            AfterFillSchemaTable(currentTable);

            // End: FillSchemaTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Дополнительные настройки схемы таблицы currentTable, 
        /// выполняемые после FillSchemaTable.
        /// </summary>
        /// <param name="currentTable">текущая таблица</param>
        protected virtual void AfterFillSchemaTable(DataTable currentTable)
        {
            // Изменить начальное значение и шаг автоинкремента
            currentTable.Columns["Id"].AutoIncrementSeed = -1;
            currentTable.Columns["Id"].AutoIncrementStep = -1;

            // End: AfterFillSchemaTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обновить строку row (DataRow) данными из соответствующей строки SQL-сервера
        /// </summary>
        /// <param name="row">Строка таблицы данных</param>
        public virtual void RefreshRow(DataRow row)
        {
            if (row == null) return;

            int id = (int)row["Id"]; //Код Id строки

            // Создать SqlDataAdapter для заполнения таблицы oneRowTable (тип DataTable) строкой (Id = id) из таблицы SQL-сервера
            adapterRow = CreateSqlAdapter(model.CreateSelectRowSqlCommand(id));

            // Таблица с одной строкой (ID = id) с текущими данными SQL-сервера
            DataTable oneRowTable = new DataTable();

            try
            {
                // C помощью адаптара на получение диапазоном строк 
                // заполняет таблицу table схемой и данными из соответствующей её таблицы SQL-сервера
                FillSchemaTable(adapterRows, oneRowTable);
                adapterRow.Fill(oneRowTable);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // Если строка получена из SQL-сервера
            if (oneRowTable.Rows.Count > 0)
            {
                DataRow row2 = oneRowTable.Rows[0]; // Получить строку с текущими значениями полей

                // Перебрать все столбцы таблицы oneRowTable и 
                // заменить значения столбцов строки row на значения столбцов строки row2
                foreach (DataColumn column in oneRowTable.Columns)
                {
                    // Если столбец не ReadOnly
                    if (column.ReadOnly == false)
                    {
                        try
                        {
                            row[column.ColumnName] = row2[column.ColumnName];
                        }
                        catch (Exception exc)
                        {
                            Console.WriteLine("  " + exc.Message);
                        }
                    }
                    // Иначе если столбец ReadOnly
                    else
                    {
                        try
                        {
                           row.Table.Columns[column.ColumnName].ReadOnly = false;
                           row[column.ColumnName] = row2[column.ColumnName];
                        }
                        catch (Exception exc)
                        {
                            Console.WriteLine("  " + exc.Message);
                        }
                        finally
                        {
                            row.Table.Columns[column.ColumnName].ReadOnly = true;
                        }
                    }
                }
            }

            // End: RefreshRow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Выполняется перед методом обновления данных таблицы
        /// для передачи значений параметров SQL-команды
        /// </summary>
        protected virtual void BeforeRefreshTable()
        {
            // End: BeforeRefreshTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)
        /// </summary>
        public virtual void FirstRefreshTable()
        {
            // Выполняется перед обновление данных таблицы
            BeforeRefreshTable();

            // Создает SqlDataAdapter для заполнения таблицы table (тип DataTable) диапазоном строк из таблицы SQL-сервера
            adapterRows = CreateSqlAdapter(model.CreateSelectRowsSqlCommand());

            // Текущая таблица данных типа DataTable, заполняемая строками из соответствующей ей таблицы SQL-сервера
            table = new DataTable(tableName);

            try
            {
                // C помощью адаптара на получение диапазоном строк 
                // заполняет таблицу table схемой и данными из соответствующей её таблицы SQL-сервера
                FillSchemaTable(adapterRows, table);
                adapterRows.Fill(table);

                // Создает представление (DataView) по данным таблицы table
                tableView = new DataView(table, "", sortString, DataViewRowState.CurrentRows);
                // Передаем созданное представление элементу ListView в качестве источника данных
                //tableListView.List.ItemsSource = tableView;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // End: FirstRefreshTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обновить данные таблицы table (тип DataTable)
        /// </summary>
        public virtual void RefreshTable()
        {
            // Выполняется перед обновление данных таблицы
            BeforeRefreshTable();

            // Локальные переменные метода
            // ---------------------------
            DataView tableView = null; // Представление таблицы типа DataTable
            DataRowView rowViewSelected = null; // выделенная строка объекта List (типа ListView)
            int selectedId = 0;     // Id - выделенной строки
            int selectedIndex = -1; // Индекс выделенной строки

            // Проверки на допустимость выполнения метода
            // ------------------------------------------
            try
            {
                tableView = tableListView.List.ItemsSource as DataView; // Представление таблицы покупателей
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка времени выполнения", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // Если в ItemsSource объекта List (типа ListView) не задана коллекция в виде представления, то завершить метод
            if (tableView == null) return;
           
            tableListView.IsButtonEnabled = false; // Заблокировать кнопки
            tableListView.MessText = "Идет обновление данных. Ждите..."; // Сообщение в строке состояния окна типа TableListView

            // Если есть выделенная строка, то запомнить ее Id  и индекс
            // ---------------------------------------------------------
            if (tableListView.List.SelectedIndex >= 0)
            {
                // Получить выделенную строку объекта List (типа ListView)
                rowViewSelected = tableListView.List.SelectedItem as DataRowView; 

                selectedId = (int)rowViewSelected["Id"]; // Получить Id - выделенной строки
                selectedIndex = tableListView.List.SelectedIndex; // Получить индекс выделенной строки
            }

            // Загрузить во вторичном потоке схему и данные из SQL-сервера в таблицу customers 
            // --------------------------------------------------------------------------------
            //Thread thread = new Thread(FillTable);
            //thread.Start();

            //Task task = new Task(FillTable);
            //task.Start();

            //Task.Run(new Action(FillTable));

            Task.Run(() => FillTable(selectedId, selectedIndex));

            // ----------------------------------------------------------------------------------------
            // End: RefreshTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Загрузить схему и данные из SQL-сервера в новую таблицу типа DataTable
        /// </summary>
        /// <param name="currentSellectId">Id выделенной строки текущей таблицы</param>
        /// <param name="currentSelectedIndex">Индекс выделенной строки текущей таблицы</param>
        protected virtual void FillTable(int SellectId, int SelectedIndex)
        {
            //Thread.Sleep(5000);


            // Загрузить с помощью адаптара текущие данные из таблицы SQL-сервера в новую таблицу типа DataTable
            // -------------------------------------------------------------------------------------------------

            DataTable newTable = new DataTable(tableName); // Создаем новую таблицу типа DataTable

            // Создает SqlDataAdapter для заполнения таблицы newTable (тип DataTable) диапазоном строк из таблицы SQL-сервера
            adapterRows = CreateSqlAdapter(model.CreateSelectRowsSqlCommand());

            errorMessage = null; // Сообщение об ошибке
            try
            {
                // C помощью адаптара на получение диапазоном строк 
                // заполняет таблицу newTable схемой и данными из соответствующей её таблицы SQL-сервера
                FillSchemaTable(adapterRows, newTable);
                adapterRows.Fill(newTable);

                //Thread.Sleep(10000);
            }
            catch (Exception exc)
            {
                errorMessage = exc.Message;
            }

            // Метод, выполняемый после окончания загрузки данных 
            ThreeArgDelegate actionAfterFillTable = new ThreeArgDelegate(AfterFillTable);
            tableListView.Win.Dispatcher.BeginInvoke(DispatcherPriority.Normal, actionAfterFillTable,
                                                     newTable, SellectId, SelectedIndex);

            // ----------------------------------------------------------------------------------------
            // End: FillTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Выполняется после окончания загрузки данных в новую таблицу типа DataTable из соответствующей ей таблицы SQL-сервера
        /// Id и индекса выделенной строки текущей таблицы
        /// </summary>
        /// <param name="newTable">Новая таблица</param>
        /// <param name="selectedId">Id выделенной строки текущей таблицы</param>
        /// <param name="selectedIndex">Индекс выделенной текущей старой таблицы</param>
        protected virtual void AfterFillTable(DataTable newTable, int selectedId, int selectedIndex)
        {
            // Если есть ошибка при обновлении данных, то показать сообщение об ошибке
            if (errorMessage != null)
            {
                MessageBox.Show(errorMessage, "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            // Иначе если обновление данных прошло успешно
            else
            {
                // Если схема и данные успешно загружены в новую таблицу типа DataTable,
                // то передаем текущей таблице ссылку на новую таблицу 
                table = newTable;
                // Создаем представление по новым данным и передаем его в List (тип ListView)
                tableView = new DataView(table, "", sortString, DataViewRowState.CurrentRows);
                tableListView.List.ItemsSource = tableView;

                // Если до обновления данных была выделенная строка, выделить ее или 
                // если этой строки нет, то строку с тем же индексом
                // -----------------------------------------------------------------
                if (selectedIndex >= 0)
                {
                    // Сделать выделенной строкой строку с Id = selectedId.
                    // Если такая строка не найдена, то строку с индексом равным selectedIndex.
                    SelectedRowViewById(selectedId, selectedIndex);

                    // Установить фокус на выделенную строку
                    SetFocusToSelectedItem();
                }
                else
                {
                    // Перейти к первой строке таблицы
                    ToFirstRow();
                }
            }

            tableListView.IsButtonEnabled = true; // Разблокировать кнопки
            tableListView.MessText = ""; // Убрать сообщение из строки состояния

            // ----------------------------------------------------------------------------------------
            // End: AfterFillTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавить строку таблицы DataTable. Возвращает результат добавления.
        /// </summary>
        /// <param name="updateView">Диалоговое окно добавления/изменения строки табицы</param>
        /// <param name="addParam">Дополнительный параметр метода инициализации окна updateView</param>
        /// <returns>Возвращает результат добавления.</returns>
        public virtual bool? InsertRowTable(ITableUpdateView updateView, object addParam=null)
        {
            bool? result = false; // Результат добавления

            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;

            // Если в ItemsSource List не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return result;

            // Получить текущую таблицу 
            DataTable currentTable = currentTableView.Table;

            // Добавить новую строку в представление currentTableView
            DataRowView viewRowInsert = currentTableView.AddNew();

            // Запомнить идентификатор новой строки в представлении
            int id = (int)viewRowInsert["Id"];
            // Временно установить идентификатор новой строки в представлении равным нулю
            currentTable.Columns["Id"].ReadOnly = false;
            viewRowInsert["Id"] = 0;
            currentTable.Columns["Id"].ReadOnly = true;

            // Иницилизация полей и свойств окна добавления/изменения строки в режиме добавления
            updateView.InitializeUpdateView(this, viewRowInsert, DialogMode.AddMode, id, addParam);
            updateView.Win.Owner = tableListView.Win;

            if (updateView.Win.ShowDialog() == true)
            {
                // Получить идентификатор новой строки после добавление строки в таблице SQL-сервера
                id = updateView.Id;

                if (viewRowInsert != null)
                {
                    tableListView.List.SelectedItem = viewRowInsert;
                    tableListView.List.ScrollIntoView(viewRowInsert);

                    // Обновить строку row (DataRow) данными из соответствующей строки SQL-сервера
                    RefreshRow(viewRowInsert.Row);
                }

                result = true; // Результат добавления
            }

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();

            return result;

            // End: InsertRowTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Изменить выделенную строку таблицы DataTable. Возвращает результат изменения.
        /// </summary>
        /// <param name="updateView">Диалоговое окно добавления/изменения строки табицы</param>
        /// <param name="addParam">Дополнительный параметр метода инициализации окна updateView</param>
        /// <returns>Возвращает результат изменения.</returns>
        public virtual bool? ChangeRowTable(ITableUpdateView updateView, object addParam = null)
        {
            bool? result = false; // Результат изменения

            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;

            // Если в ItemsSource listView1 не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return result;

            // Получить текущую таблицу 
            DataTable currentTable = currentTableView.Table;

            // Получить выделенную строку для ее редактирования
            DataRowView viewRowChange = tableListView.List.SelectedItem as DataRowView;

            // Если выделенной строки не существует, то завершить метод
            if (viewRowChange == null) return result;

            int id = (int)viewRowChange["Id"]; // Код идентификатора записи

            // Обновить строку row (DataRow) данными из соответствующей строки SQL-сервера
            RefreshRow(viewRowChange.Row);

            // Иницилизация полей и свойств окна добавления/изменения строки в режиме изменения
            updateView.InitializeUpdateView(this, viewRowChange, DialogMode.ChangeMode, id, addParam);
            updateView.Win.Owner = tableListView.Win;

            if (updateView.Win.ShowDialog() == true)
            {
                // Обновить строку row (DataRow) данными из соответствующей строки SQL-сервера
                RefreshRow(viewRowChange.Row);

                result = true; // Результат изменения
            }

            

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();

            return result;

            // End: InsertCustomer
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Удалить выделенную строку таблицы DataTable и соответствующую ей строку таблицы SQL-сервера
        /// Возвращает количество удаленных строк
        /// </summary>
        /// <returns></returns>
        public virtual int DeleteRowTable()
        {
            int countDelete = 0; // Количество удаленных строк

            int selectedId = 0;     // Id - выделенной строки
            int selectedIndex = -1; // Индекс выделенной строки

            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;

            // Если в ItemsSource listView1 не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return countDelete;

            // Получить текущую таблицу
            DataTable currentTable = currentTableView.Table;

            // Получить выделенную строку
            DataRowView selectedRow = tableListView.List.SelectedItem as DataRowView;

            // Если выделенной строки не существует, то завершить метод
            if (selectedRow == null) return countDelete;

            selectedId = (int)selectedRow["Id"];  // Id - выделенной строки
            selectedIndex = tableListView.List.SelectedIndex; // Индекс выделенного элемента

            MessageBoxResult res = MessageBox.Show("Вы уверены что хотите удалить этого покупателя?", "Удаление строки",
                                                    MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (res == MessageBoxResult.Yes)
            {
                // Удалить выделенную строку таблицы customers SQL-сервера
                countDelete = model.DeleteTableRow(selectedRow.Row);

                // Если выделенная строка таблицы customers уже была удалена на SQL сервере, то выдать сообщение об этом
                if (countDelete == 0)
                {
                    MessageBox.Show("Данная строка уже удалена на сервере!", "Предупреждение",
                                     MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                selectedRow.Row.Delete();
                currentTable.AcceptChanges();

                // Сделать выделенной строкой строку с Id = selectedId.
                // Если такая строка не найдена, то строку с индексом равным selectedIndex.
                SelectedRowViewById(selectedId, selectedIndex);
            }

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();

            return countDelete;

            // End: DeleteCustomer
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавление/изменение строки таблицы SQL-сервера при закрытии окна UpdateView
        /// Возвращает true - Отмена закрытия окна, false - закрытие окна
        /// </summary>
        /// <param name="rowView">Представление добавляемой или изменяемой строки таблицы покупателей</param>
        /// <param name="mode">Перечисление: Режим добавления или изменения</param>
        /// <param name="id">Код идентификатора покупателя</param>
        /// <param name="dialogResult">Результат работы с диалоговым окном (true/false/null)</param>
        /// <returns></returns>
        public virtual bool UpdateViewClosing(DataRowView rowView, DialogMode mode, ref int id, bool? dialogResult)
        {
            bool cancel = false; // true - Отмена закрытия окна
            int countChange = 0; // Количество измененных строк для режима изменения

            // Нажата клавиша "Согласен"
            if (dialogResult == true)
            {
                // Сохраняет изменения в MS SQL базе данных
                // ----------------------------------------
                DataTable currentTable = rowView.DataView.Table; // Таблица покупателей

                // Если режим добавления
                if (mode == DialogMode.AddMode)
                {
                    // Вернуть изначальный код покупателя в представлении новой строки 
                    currentTable.Columns["Id"].ReadOnly = false;
                    rowView["Id"] = id;
                    currentTable.Columns["Id"].ReadOnly = true;
                    
                    id = model.InsertTableRow(rowView.Row); // Добавить строку в таблицу в базе данных

                    if (id == 0) MessageBox.Show("Не удалось сохранить добавленную строку в базе данных!",
                                                 "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                // Иначе если режим изменения 
                else if (mode == DialogMode.ChangeMode)
                {
                    countChange = model.ChangeTableRow(rowView.Row); // Изменить строку в таблице базы данных

                    // Если Данная запись не найдена в базе данных на сервере
                    // (вероятно удалена другим пользователем)
                    if (countChange == 0)
                    {
                        MessageBoxResult result = MessageBox.Show("Данная запись не найдена в базе данных на сервере " +
                                         "(вероятно удалена другим пользователем). Добавить ее снова?",
                                         "Предупреждение", MessageBoxButton.OKCancel, MessageBoxImage.Warning);

                        // Если добавить снова
                        if (result == MessageBoxResult.OK)
                        {
                            id = model.InsertTableRow(rowView.Row); // Добавить строку в таблицу в базе данных

                            if (id == 0) MessageBox.Show("Не удалось сохранить добавленную строку в базе данных!",
                                     "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                        else
                        {
                            // Отмена закрытия окна
                            cancel = true;
                            return cancel;
                        }
                    }
                }

                // Если при добавлении или изменении данных произошла ошибка
                if ((id == -1) || (countChange == -1))
                {
                    // Отмена закрытия окна
                    cancel = true;
                    return cancel;
                }

                // Завершить режим редактирования строки представления
                // ---------------------------------------------------
                try
                {
                    rowView.EndEdit();
                    rowView.Row.AcceptChanges(); // Фиксирует все изменения, внесенные в строку
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
            } // if (dialogResult == true)

            // Нажата клавиша "Отмена" или крестик в правом верхнем углу окна
            if (dialogResult == false)
            {
                // Если режим добавления
                if (mode == DialogMode.AddMode)
                {
                    rowView.CancelEdit(); // Отменяет добавленную строку представления
                }
                // Иначе если режим изменения 
                else if (mode == DialogMode.ChangeMode)
                {
                    rowView.CancelEdit(); // Отменяет добавленную строку представления
                    rowView.Row.RejectChanges(); // Отклоняет все изменения внесенные в строку
                } // if (dialogResult == false)
            }

            return cancel;
        }

        #endregion
    }
}
