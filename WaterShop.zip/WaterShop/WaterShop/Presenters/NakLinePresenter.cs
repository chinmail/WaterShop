﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Windows.Threading;
using WaterShop.Models;
using WaterShop.Infrastructure;

namespace WaterShop.Presenters
{
    /// <summary>
    /// Презентор строк накладной
    /// </summary>
    public class NakLinePresenter : BaseTablePresenter
    {
        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Код накладной
        /// </summary>
        public int IdNak { get; set; }

        /// <summary>
        /// Свойство: Представление таблицы NakLine
        /// </summary>
        public DataView NakLineView
        {
            get
            {
                return tableView;
            }
            set
            {
                tableView = value;
            }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Презентор строк накладной
        /// </summary>
        public NakLinePresenter()
        {
            // Получить текущий код накладной
            //IdNak = (Application.Current as App).IdNakCurrent;

            // Инициализация модели данных: Добавление, изменение и удаление строки/строк таблицы NakLine(строки накладной) SQL-сервера
            model = new NakLineModel();

            // Имя таблицы DataTable
            tableName = "NakLine";

            // Строка сортировки для строк представления tableView
            sortString = "idNak, Id";

            // Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)
            //FirstRefreshTable();

            // End: NakHdrPresenter
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Выполняется перед методом обновления данных таблицы
        /// для передачи значений параметров SQL-команды
        /// </summary>
        protected override void BeforeRefreshTable()
        {
            base.BeforeRefreshTable();

            // Делаем downcast модели
            NakLineModel nakLineModel = model as NakLineModel;

            // Если downcast модели удачен
            if (nakLineModel != null)
            {
                // Устнавливаем код накладной
                nakLineModel.IdNak = IdNak;
            }

            // End: BeforeRefreshTable
            // ----------------------------------------------------------------------------------------
        }

        #endregion

    }
}
