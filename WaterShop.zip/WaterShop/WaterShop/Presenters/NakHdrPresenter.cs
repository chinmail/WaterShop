﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Windows.Threading;
using WaterShop.Models;
using WaterShop.Infrastructure;
using WaterShop.Views;

namespace WaterShop.Presenters
{
    /// <summary>
    /// Презентор списка заголовков накладных
    /// </summary>
    public class NakHdrPresenter : BaseTablePresenter
    {
        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Дата начала диапозона
        /// </summary>
        public DateTime Date1 { get; set; }

        /// <summary>
        /// Дата конца диапозона
        /// </summary>
        public DateTime Date2 { get; set; }

        /// <summary>
        /// Свойство: Представление таблицы NakHdr
        /// </summary>
        public DataView NakHdrView
        {
            get
            {
                return tableView;
            }
            set
            {
                tableView = value;
            }
        }

        #endregion

        // Конструкторы
        // ---------------------------------------------------------------------------------
        #region Constructors

        /// <summary>
        /// Презентор для списка заголовков накладных
        /// </summary>
        public NakHdrPresenter()
        {
            Date2 = DateTime.Today; // Установить дату конца диапозона, как текущую дату 
            Date1 = Date2.AddDays(-30); // Установить дату начала диапозона, как текущую дату минус 30 дней

            // Инициализация модели данных: Добавление, изменение и удаление строки/строк таблицы NakHdr(Заголовки накладных) SQL-сервера
            model = new NakHdrModel();

            // Имя таблицы DataTable
            tableName = "NakHdr";

            // Строка сортировки для строк представления tableView
            sortString = "NakDate";

            // Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)
            //FirstRefreshTable();

            // End: NakHdrPresenter
            // ----------------------------------------------------------------------------------------
        }

        #endregion

        // Методы
        // ---------------------------------------------------------------------------------
        #region Methods

        /// <summary>
        /// Выполнение хранимой процедуры, для получения номера текущей накладной
        /// </summary>
        /// <returns></returns>
        public virtual string GetNakNumber()
        {
            return (model as NakHdrModel).GetNakNumber();

            // End: GetNakNumber
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Выполняется перед методом обновления данных таблицы
        /// для передачи значений параметров SQL-команды
        /// </summary>
        protected override void BeforeRefreshTable()
        {
            base.BeforeRefreshTable();

            // Делаем downcast модели
            NakHdrModel nakHdrModel = model as NakHdrModel;

            // Если downcast модели удачен
            if (nakHdrModel != null)
            {
                // Устанавливаем дату начала диапозона модели как Date1 с временем 00:00:00
                nakHdrModel.Date1 = new DateTime(Date1.Year, Date1.Month, Date1.Day, 0, 0, 0);
                // Устанавливаем дату конца диапозона модели как Date2 c временем 23:59:59
                nakHdrModel.Date2 = new DateTime(Date2.Year, Date2.Month, Date2.Day, 23, 59, 59);
            }

            // End: BeforeRefreshTable
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Добавление накладной
        /// </summary>
        public void InsertNakl()
        {
            // Получить текущее представление таблицы из ItemsSource объекта ListView 
            DataView currentTableView = tableListView.List.ItemsSource as DataView;

            // Если в ItemsSource List не задана коллекция в виде представления, то завершить метод
            if (currentTableView == null) return;

            // Получить текущую таблицу 
            DataTable currentTable = currentTableView.Table;

            // Добавить новую строку в представление currentTableView
            DataRowView viewRowInsert = currentTableView.AddNew();

            // Запомнить идентификатор новой строки в представлении
            int id = (int)viewRowInsert["Id"]; 
            // Временно установить идентификатор новой строки в представлении равным нулю
            currentTable.Columns["Id"].ReadOnly = false;
            viewRowInsert["Id"] = 0;
            currentTable.Columns["Id"].ReadOnly = true;

            // Диалоговое окно добавления/изменения заголовка накладной
            NakHdrUpdateView updateView = new NakHdrUpdateView();

            // Иницилизация полей и свойств окна добавления/изменения строки в режиме добавления
            updateView.InitializeUpdateView(this, viewRowInsert, DialogMode.AddMode, id);
            updateView.Owner = tableListView.Win;

            if (updateView.Win.ShowDialog() == true)
            {
                // Получить Код накладной (Идентификатор) новой строки после добавление строки в таблице SQL-сервера
                int idNak = updateView.Id; 

                if (viewRowInsert != null)
                {
                    tableListView.List.SelectedItem = viewRowInsert;
                    tableListView.List.ScrollIntoView(viewRowInsert);

                    // Обновить строку row (DataRow) данными из соответствующей строки SQL-сервера
                    RefreshRow(viewRowInsert.Row);
                }

                // Создать и открыть в модальном режиме окно накладной
                NakLineListView NakLineList = new NakLineListView(idNak, this, viewRowInsert);
                NakLineList.Owner = TableListView.Win;
                NakLineList.ShowDialog();

                // Обновить строку заголовка накладной данными из соответствующей строки списка заголовков накладных SQL-сервера
                RefreshRow(viewRowInsert.Row);
            }

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();
        }

        /// <summary>
        /// Изменение накладной
        /// </summary>
        public void ChangeNakl()
        {
            // Получить представление таблицы списка заголовков накладных 
            DataView nakHdrView = tableListView.List.ItemsSource as DataView;

            // Если представление таблицы списка заголовков накладных получить не удалось, то завершить метод
            if (nakHdrView == null) return;

            // Получить выделенную строку списка заголовков накладных
            DataRowView viewRowSelected = tableListView.List.SelectedItem as DataRowView;

            // Если выделенной строки не существует, то завершить метод
            if (viewRowSelected == null) return;

            int idNak = (int)viewRowSelected["Id"]; // Получить код накладной (Код идентификатора записи) 

            // Обновить строку заголовка накладной данными из соответствующей строки списка заголовков накладных SQL-сервера
            RefreshRow(viewRowSelected.Row);

            // Создать и открыть в модальном режиме окно накладной
            NakLineListView NakLineList = new NakLineListView(idNak, this, viewRowSelected);
            NakLineList.Owner = TableListView.Win;
            NakLineList.ShowDialog();

            // Обновить строку заголовка накладной данными из соответствующей строки списка заголовков накладных SQL-сервера
            RefreshRow(viewRowSelected.Row);

            // Установить фокус на выделенную строку
            SetFocusToSelectedItem();
        }

        #endregion
    }
}
