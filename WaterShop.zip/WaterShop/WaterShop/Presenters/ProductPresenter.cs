﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using WaterShop.Models;
using WaterShop.Infrastructure;

namespace WaterShop.Presenters
{
    /// <summary>
    /// Презентор списка товаров
    /// </summary>
    class ProductPresenter : BaseTablePresenter
    {
        /// <summary>
        /// Свойство: Представление таблицы Product
        /// </summary>
        public DataView ProductView
        {
            get
            {
                return tableView;
            }
            set
            {
                tableView = value;
            }
        }

        /// <summary>
        /// Презентор для списка товаров
        /// </summary>
        public ProductPresenter()
        {            
            // Инициализация модели данных: Добавление, изменение и удаление строки/строк таблицы Product(товары) SQL-сервера
            model = new ProductModel();

            // Имя таблицы DataTable
            tableName = "Product";

            // Строка сортировки для строк представления tableView
            sortString = "Name";

            // Первый раз после загрузки окна типа TableListView обновить данные таблицы table (тип DataTable)
            //FirstRefreshTable();

            // End: ProductPresenter
            // ----------------------------------------------------------------------------------------
        }
    }
}
