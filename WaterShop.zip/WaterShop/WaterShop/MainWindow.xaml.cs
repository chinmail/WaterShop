﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WaterShop.Views;

namespace WaterShop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Главное меню
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            // End: MainWindow
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Пункт меню "Список накладных"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void NakList_Click(object sender, RoutedEventArgs args)
        {
            // Создать и открыть в немодальном режиме окно списка накладных
            NakHdrListView NakHdrList = new NakHdrListView();
            NakHdrList.Owner = this;
            NakHdrList.Show();

            // End: NakList_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Пункт меню "Список покупателей"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void CustomersList_Click(object sender, RoutedEventArgs args)
        {
            // Создать и открыть в немодальном режиме окно списка покупателей
            CustomersListView customerList = new CustomersListView();
            customerList.Owner = this;
            customerList.Show();

            // End: CustomersList_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Пункт меню "Список товаров"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void ProductList_Click(object sender, RoutedEventArgs args)
        {
            // Создать и открыть в немодальном режиме окно списка товаров
            ProductListView productList = new ProductListView();
            productList.Owner = this;
            productList.Show();

            // End: ProductList_Click
            // ----------------------------------------------------------------------------------------

        }

        /// <summary>
        /// Пункт меню "О программе WaterShop"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void AboutProgram_Click(object sender, RoutedEventArgs args)
        {
            // Создать и открыть в модальном режиме окно "О программе WaterShop"
            AboutProgram about = new AboutProgram();
            about.Owner = this;
            about.ShowDialog();

            // End: ProductList_Click
            // ----------------------------------------------------------------------------------------

        }

        /// <summary>
        /// Пункт меню "Выход из программы"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void CloseApplication_Click(object sender, RoutedEventArgs args)
        {
            Close();

            // End: CloseApplication_Click
            // ----------------------------------------------------------------------------------------
        }

        /// <summary>
        /// Обработка события, вызываемого при закрытии окна 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs args)
        {
            Application.Current.Shutdown(0);

            // End: Window_Closing
            // ----------------------------------------------------------------------------------------
        }
    }
}
