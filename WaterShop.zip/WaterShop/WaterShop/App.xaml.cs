﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WaterShop
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Поля
        // ---------------------------------------------------------------------------------
        #region fields

        /// <summary>
        /// Строка подключения к SQL базе данных
        /// @"Data Source=.\SERVER2012; Initial Catalog=WaterShop; Integrated Security=True; Pooling = true;"
        /// </summary>
        private string connectionString;

        /// <summary>
        /// Соединенние с базой SQL-сервера
        /// </summary>
        private SqlConnection connection = null;

        #endregion

        // Свойства
        // ---------------------------------------------------------------------------------
        #region properties

        /// <summary>
        /// Свойство: Строка подключения к SQL базе данных
        /// </summary>
        public string ConnectionString
        {
            get { return connectionString; }
        }

        /// <summary>
        /// Свойство: соединенние с базой SQL-сервера
        /// </summary>
        public SqlConnection Connection
        {
            get { return connection; }
        }

        #endregion

        /// <summary>
        /// Обработка события Startup
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStartup(StartupEventArgs args)
        {
            base.OnStartup(args);

            //// Объект ConnectionStringSetting представляет собой отдельную строку подключения
            //// в разделе строк подключения конфигурационного файла
            //ConnectionStringSettings setting = new ConnectionStringSettings("ConnectionString", connectionString);
            //// Объект config представляет конфигурационный файл
            //Configuration config;
            //// Объект ConfigurationManager предоставляет доступ к файлам конфигурации
            //config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            //config.ConnectionStrings.ConnectionStrings.Add(setting);
            //config.Save();

            // Получение строки подключения из конфигурационного файла
            connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

            // Инициализация cтроки подключения к SQL базе данных
            connection = new SqlConnection(connectionString);

            // End: OnStartup
            // ----------------------------------------------------------------------------------------
        }
    }
}
